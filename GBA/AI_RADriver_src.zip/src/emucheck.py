#!/usr/bin/env python3
"""emucheck.py ROM -- run RADriver's own code from the ROM in an ARM emulator (unicorn) and
compare it, frame by frame, with radriver_model.py. Every driver byte of IWRAM and EWRAM
(ring buffer, accumulator, voices, variables, pitch table, sequencer tracks) must match
after snd_init and after every snd_update.

Scenario 1 replays the game's own use of the driver (snd_init(11025, 2), music streams
and sound effects) plus stress cases; scenario 2 drives the sequencer, which Aggressive
Inline itself never uses, with a synthetic song in EWRAM that exercises every command.
"""
import sys, random, struct
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm_const import *
import radriver_model as M

ROM = open(sys.argv[1] if len(sys.argv) > 1 else '../../Aggressive Inline (E) (M3).gba', 'rb').read()
F = dict(init=0x0805B3C8, update=0x0805B66C, playStream=0x0805B80C, playSfx=0x0805BA78, stop=0x0805B90C,
         pause=0x0805B920, resume=0x0805B934, setVolume=0x0805B950, setPitch=0x0805B970, setBank=0x0805B99C,
         playSong=0x0805BA24, playSample=0x0805B86C)
RET = 0x0203F000
IWRAM_IMG = (0x087E1594, 0x03005D2C, 0x03007204)       # crt0 .data copy: ROM src, dst, end
HEAP_RAM, HEAP_EX, HANDLES = 0x03000400, 0x02010000, 0x0203E000


class Emu:
    def __init__(self):
        u = self.u = Uc(UC_ARCH_ARM, UC_MODE_ARM)
        u.ctl_set_cpu_model(UC_CPU_ARM_926)
        u.mem_map(0x08000000, 0x02000000); u.mem_write(0x08000000, ROM)
        u.mem_map(0x02000000, 0x40000); u.mem_map(0x03000000, 0x8000); u.mem_map(0x04000000, 0x1000)
        s, d, e = IWRAM_IMG
        u.mem_write(d, ROM[s - 0x08000000:s - 0x08000000 + (e - d)])
        u.reg_write(UC_ARM_REG_SP, 0x03007F00)
        # the game's heap is replaced by fixed blocks (the model is given the same ones)
        u.mem_write(HANDLES, struct.pack('<II', HEAP_RAM, HEAP_EX))
        self.hooks = {0x080534D8: HANDLES, 0x0805353C: HANDLES + 4, 0x080535A0: 0}
        u.hook_add(UC_HOOK_CODE, self._hook, begin=0x08050000, end=0x08056000)

    def _hook(self, u, addr, size, _):
        if addr in self.hooks:                    # iwram_alloc / exram_alloc / mem_free
            u.reg_write(UC_ARM_REG_R0, self.hooks[addr])
            u.reg_write(UC_ARM_REG_PC, u.reg_read(UC_ARM_REG_LR))

    def call(self, fn, *args):
        u = self.u
        for r, a in zip((UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3), args):
            u.reg_write(r, a & 0xFFFFFFFF)
        u.reg_write(UC_ARM_REG_LR, RET | 1)
        u.emu_start(fn | 1, RET, count=50_000_000)
        r0 = u.reg_read(UC_ARM_REG_R0)
        return r0 - (1 << 32) if r0 & 0x80000000 else r0

    def set_tm1(self, v): self.u.mem_write(0x04000104, struct.pack('<H', v & 0xFFFF))


REGIONS = [(0x03001298, 0x030012AC), (0x03005CB0, 0x03005D2C), (HEAP_RAM, HEAP_RAM + 288 * 3 + 16 * 40),
           (HEAP_EX, HEAP_EX + 0x440)]


def compare(emu, mem, what):
    for lo, hi in REGIONS:
        a = bytes(emu.u.mem_read(lo, hi - lo))
        b = bytes(mem._buf(lo)[0][mem._buf(lo)[1]:mem._buf(lo)[1] + hi - lo])
        if a != b:
            i = next(i for i in range(len(a)) if a[i] != b[i])
            raise SystemExit(f'MISMATCH after {what} at {lo + i:08X}: emu {a[i:i+8].hex()} model {b[i:i+8].hex()}')


def both(emu, drv, name, *args):
    r = emu.call(F[name], *args)
    m = getattr(drv, name)(*args)
    if m is not None and name not in ('stop','pause','resume','setVolume','setPitch','setBank') and r != m: raise SystemExit(f'return value of {name}{args}: emu {r} model {m}')
    return r


def setup(voices, rate=11025):
    emu = Emu(); mem = M.Mem(ROM); drv = M.RADriver(mem)
    s, d, e = IWRAM_IMG
    mem.iw[d - 0x03000000:e - 0x03000000] = ROM[s - 0x08000000:s - 0x08000000 + (e - d)]
    emu.call(F['init'], rate, voices)
    mem.w32(HANDLES, HEAP_RAM); mem.w32(HANDLES + 4, HEAP_EX)
    drv.init(rate, voices, HANDLES, HANDLES + 4)
    compare(emu, mem, 'snd_init')
    return emu, mem, drv


def frames(emu, mem, drv, n, rng, cursor, events):
    bs = mem.r16(M.BUFSIZE); lo = 0x10000 - bs
    for f in range(n):
        if events: events(f)
        step = rng.choice([184, 184, 185, 185, 186, 2, 4, 100, 286, 300, 450]) if rng.random() < 0.15 else rng.choice([184, 185])
        cursor = lo + ((cursor - lo + step) % bs)
        emu.set_tm1(cursor - 1); mem.tm1 = cursor - 1    # the driver rounds (count+1) up to even
        emu.call(F['update']); drv.update()
        compare(emu, mem, f'frame {f} (cursor {cursor:04X})')
    return cursor


def scenario_game(nframes):
    rng = random.Random(1)
    emu, mem, drv = setup(2)
    both(emu, drv, 'setBank', 0x08031608)
    handles = []
    st = 0x0806AEDC
    def ev(f):
        if f % 900 == 0:                          # a new music stream every 15 s
            for h in handles[:1]: both(emu, drv, 'stop', h)
            handles[:1] = []
            s = (f // 900) % 16
            blocks, order = struct.unpack_from('<II', ROM, st - 0x08000000 + 8 * s)
            h = both(emu, drv, 'playStream', blocks, order); handles.insert(0, h)
            both(emu, drv, 'setVolume', h, rng.choice([96, 128, 200, 256]))
        if rng.random() < 0.05:
            h = both(emu, drv, 'playSfx', rng.randrange(32), rng.choice([60, 60, 48, 72, 127, 140]))
            if h >= 0: both(emu, drv, 'setVolume', h, rng.randrange(300))
        if rng.random() < 0.01 and len(handles) > 1: both(emu, drv, 'stop', handles.pop())
        if rng.random() < 0.01 and handles: both(emu, drv, 'pause', handles[0])
        if rng.random() < 0.02 and handles: both(emu, drv, 'resume', handles[0])
        if rng.random() < 0.01 and len(handles) > 1: both(emu, drv, 'setPitch', handles[-1], rng.randrange(140))
    frames(emu, mem, drv, nframes, rng, 0x10000 - 288, ev)
    return nframes


def scenario_seq(nframes):
    """synthetic bank in EWRAM: 2 songs using AI's effects as programs."""
    rng = random.Random(2)
    emu, mem, drv = setup(8)
    BANK, SONG = 0x02020000, 0x02020100
    smp = [struct.unpack_from('<I', ROM, 0x31618 + 4 * i)[0] for i in range(30)]
    song = bytearray(b'\xB2\x00\x04\x80\x00')                          # tempo 4.5 ticks/frame
    for bar in range(40):
        for ch in range(rng.randrange(1, 6)):
            song += bytes([0xC0 | rng.randrange(16), rng.randrange(30)])  # program change
        for k in range(rng.randrange(1, 9)):
            c = rng.choice([0x90, 0x80, 0x90, 0xA0, 0xD0, 0xE0, 0xB1, 0xB3, 0xB7]) | rng.randrange(16)
            if c >> 4 in (8, 9): song += bytes([c, rng.randrange(30, 100), rng.randrange(256)])
            elif c >> 4 == 0xD or c == 0xB1: song += bytes([c, rng.randrange(256)])
            else: song += bytes([c])
            if rng.random() < 0.6: song += struct.pack('>H', rng.randrange(0, 200))
        if bar == 20: song += b'\xB2\x00\x07\x00\x00'
    song += b'\xB0\xB3'
    loop = SONG + 5
    for addr, data in ((SONG, bytes(song)),
                       (BANK, struct.pack('<IIII', 2, 30, BANK + 16, BANK + 32) + struct.pack('<IIII', SONG, loop, SONG, SONG)
                        + b''.join(struct.pack('<I', s) for s in smp))):
        emu.u.mem_write(addr, data)
        mem.ew[addr - 0x02000000:addr - 0x02000000 + len(data)] = data
    both(emu, drv, 'setBank', BANK)
    def ev(f):
        if f % 1500 == 0: emu.call(F['playSong'], (f // 1500) % 3); drv.playSong((f // 1500) % 3)
    frames(emu, mem, drv, nframes, rng, 0x10000 - 288, ev)
    return nframes


def scenario_fullring():
    """snd_update called twice without the play cursor moving: the driver treats it as a
    full ring (n = bufSize), and the n+1th accumulator write lands on voice 0's sample
    pointer. Emulator and model must corrupt it identically."""
    rng = random.Random(3)
    emu, mem, drv = setup(2)
    both(emu, drv, 'setBank', 0x08031608)
    both(emu, drv, 'playSfx', 0, 60)               # looped PCM effect in voice 0
    cur = 0x10000 - 288
    for f in range(30):
        cur = 0x10000 - 288 + ((cur - (0x10000 - 288) + 184) % 288)
        emu.set_tm1(cur - 1); mem.tm1 = cur - 1
        emu.call(F['update']); drv.update(); compare(emu, mem, f'frame {f}')
    v0 = HEAP_RAM + 3 * 288
    before = mem.r32(v0)
    emu.call(F['update']); drv.update(); compare(emu, mem, 'repeated update')
    return before, mem.r32(v0)


if __name__ == '__main__':
    n1 = scenario_game(int(sys.argv[2]) if len(sys.argv) > 2 else 14400)
    print(f'scenario 1 (game use, 2 voices, 16 streams + effects): {n1} frames identical')
    n2 = scenario_seq(int(sys.argv[3]) if len(sys.argv) > 3 else 6000)
    print(f'scenario 2 (sequencer, 8 voices, synthetic song):        {n2} frames identical')
    b, a = scenario_fullring()
    print(f'scenario 3 (update with no cursor movement): identical in both; voice 0 sample pointer {b:08X} -> {a:08X}')

#!/usr/bin/env python3
"""export_wav.py ROM OUTDIR -- RADriver (Aggressive Inline (E)) audio as WAV.

  sfxNN.wav       the 30 PCM effects, 8-bit, 11025 Hz, exactly as stored (loop point in the name)
  sNN_bMM.wav     every ADPCM music block, 16-bit (12-bit predictor << 4), 11025 Hz
  streamNN.wav    each stream rendered by following its order list once, up to the -1
                  terminator or MAXSEC seconds, whichever comes first
The decoder is the driver's (OKI ADPCM, XOR 0xEC, state reset per block); it is checked
against radriver_model.py, which is itself checked against the ROM code by emucheck.py.
"""
import sys, os, struct, wave
import array

MAXSEC = 300
RATE = 11025


def u32(rom, a): return struct.unpack_from('<I', rom, a - 0x08000000)[0]


def tables(rom):
    diff = struct.unpack_from('<784h', rom, 0x087E0BB0 - 0x08000000)
    nxt = rom[0x087E11D0 - 0x08000000:0x087E11D0 - 0x08000000 + 392]
    return diff, nxt


def decode_block(rom, blk, diff, nxt):
    n = u32(rom, blk + 4); d = rom[blk + 16 - 0x08000000:blk + 16 + n - 0x08000000]
    out = array.array('h'); pred = 0; idx = 0
    for b in d:
        b ^= 0xEC
        for nib in (b >> 4, b & 15):
            pred += diff[idx * 16 + nib]
            pred = 2047 if pred > 2047 else (-2048 if pred < -2048 else pred)
            out.append(pred << 4)
            idx = nxt[idx * 8 + (nib & 7)]
    return out


def wav(path, data, width):
    with wave.open(path, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(width); w.setframerate(RATE)
        w.writeframes(data)


def main(rompath, outdir):
    rom = open(rompath, 'rb').read()
    os.makedirs(outdir, exist_ok=True)
    diff, nxt = tables(rom)
    bank = 0x08031608
    for i in range(u32(rom, bank + 4)):
        s = u32(rom, u32(rom, bank + 12) + 4 * i)
        n, lp = u32(rom, s + 4), u32(rom, s + 8)
        pcm = bytes((b + 128) & 0xFF for b in rom[s + 16 - 0x08000000:s + 16 + n - 0x08000000])
        wav(os.path.join(outdir, f'sfx{i:02d}' + (f'_loop{lp}' if lp else '') + '.wav'), pcm, 1)
    st = 0x0806AEDC
    for s in range(16):
        t, l = u32(rom, st + 8 * s), u32(rom, st + 8 * s + 4)
        nb = (l - t) // 4
        blocks = [decode_block(rom, u32(rom, t + 4 * i), diff, nxt) for i in range(nb)]
        for i, b in enumerate(blocks):
            wav(os.path.join(outdir, f's{s:02d}_b{i:02d}.wav'), b.tobytes(), 2)
        out = array.array('h'); j = 0
        while len(out) < MAXSEC * RATE:
            k = struct.unpack_from('<h', rom, l - 0x08000000 + 2 * j)[0]; j += 1
            if k == -1: break
            out.extend(blocks[k])
        wav(os.path.join(outdir, f'stream{s:02d}.wav'), out[:MAXSEC * RATE].tobytes(), 2)
        print(f'stream {s:2d}: {nb:2d} blocks, rendered {min(len(out), MAXSEC * RATE) / RATE:6.1f} s'
              + ('' if len(out) < MAXSEC * RATE else ' (capped)'))


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])

@ radriver_arm.s -- RADriver ARM routines (Aggressive Inline (E)). Linked to run at IWRAM 0x03006808;
@ the game's crt0 copies them there from ROM 0x087E2070 with the rest of its .data image.
	.include "radriver.inc"
	.syntax unified
	.arm
	.section .iwram.radriver,"ax",%progbits
	.balign 4

@ ==================== snd_mixVoice_arm  (03006808) ====================
@ void snd_mixVoice_arm(Voice *v, int n, int master)     // ARM, runs from IWRAM 0x03006808
@ {
@     amp  = (v->volume * master) >> 12;                 // 0..16
@     s    = v->sample;  pos = v->pos;  frac = v->frac;  step = v->step;
@     acc  = snd_accum;
@     end  = s->data + s->length;
@     over = pos + n/2 - end;                            // ADPCM: bytes that would run past the end
@     if (s->type == 0)                                  // ADPCM: stop at the end of the block
@         n = (over > 0) ? n - 2*over : n;
@     if (++snd_voicesMixed != 1) {                      // ---- accumulate path (2nd voice onward)
@         if (s->type == 0) goto done;                   // BUG: ADPCM is silently skipped here
@         if (s->type == 1 && n)
@             do { *acc++ += *(s8*)pos * amp;  (pos:frac) += step; } while (n-- > 0);   // n+1 samples
@     } else {                                           // ---- store path (first voice)
@         if (s->type == 1 && n)
@             do { *acc++  = *(s8*)pos * amp;  (pos:frac) += step; } while (n-- > 0);
@         if (s->type == 0) {                            // OKI ADPCM, 2 samples per byte, no pitch
@             pred = v->adpcmPred;  idx = v->adpcmIndex;
@             for (k = n/2; k--; ) {
@                 b = *pos++ ^ 0xEC;
@                 for (nib in {b >> 4, b & 15}) {
@                     pred = clamp(pred + adpcm_diffTable[idx][nib], -2048, 2047);
@                     *acc++ = (pred >> 3) * amp;
@                     idx = adpcm_nextIndex[idx][nib & 7];
@                 }
@                 if (over >= 0 && k == 0 && v->chainBlocks) {      // block finished: next one
@                     i = v->chainOrder[v->chainIndex++];
@                     if (i == -1) { v->chainIndex = 1; i = v->chainOrder[0]; }  // restart list
@                     if (i != -1) { k = over; s = v->sample = v->chainBlocks[i]; pos = s->data; }
@                     over = -1;  pred = 0;  idx = 0;    // every block decodes from a reset state
@                 }
@             }
@             v->adpcmIndex = idx;  v->adpcmPred = pred;
@         }
@     }
@ done:
@     v->frac = frac;  v->pos = pos;
@ }
@ // (pos:frac) += step is a 4.28 add: frac += step << 4, pos += (step >> 28) + carry.
	.global snd_mixVoice_arm
snd_mixVoice_arm:
	mov	ip, sp
	push	{r4, r5, r6, r7, r8, sb, sl, fp, ip, lr, pc}
	sub	sp, sp, #0x10
	mov	r7, r0
	ldrh	r3, [r7, #0x10]
	sub	fp, ip, #4
	mul	ip, r2, r3                         @ ip = volume * master
	ldr	r2, [r7, #0xc]
	ldr	r3, .Lw0300692C                    @ =snd_accum
	str	r2, [fp, #-0x30]
	ldr	r3, [r3]
	ldr	r8, [r7, #4]
	str	r3, [fp, #-0x2c]
	ldr	lr, [r7]
	mov	r6, r1
	ldr	r4, [r7, #8]
	lsr	sb, ip, #0xc                       @ amp = ip >> 12
	ldr	r3, [lr, #4]
	add	r0, r8, r6, lsr #1
	ldrb	r2, [lr]
	add	r3, r3, #0x10
	add	r3, lr, r3
	rsb	sl, r3, r0                         @ over = pos + n/2 - end
	cmp	r2, #0
	bne	.L0300687C
	sub	r3, r6, sl, lsl #1                 @ ADPCM: n -= 2*over if over > 0
	cmp	sl, #0
	movle	r6, r1
	movgt	r6, r3
.L0300687C:
	ldr	r2, .Lw03006930                    @ =snd_voicesMixed
	ldrb	r3, [r2]
	add	r3, r3, #1                         @ ++snd_voicesMixed
	strb	r3, [r2]
	and	r3, r3, #0xff
	cmp	r3, #1
	beq	.L030068E4                         @ first voice -> store path
	ldrb	r3, [lr]
	cmp	r3, #0
	beq	.L03006A98                         @ type 0 (ADPCM) on accumulate path: skipped
	cmp	r3, #1
	bne	.L03006A98
	cmp	r6, #0
	beq	.L03006A98
	ldr	r3, [fp, #-0x30]
	ldr	r2, [fp, #-0x2c]
.L030068BC:
	ldrsb	r0, [r8]
	ldrsh	r1, [r2]
	adds	r3, r3, r4, lsl #4                @ 4.28 step: frac += step<<4 ...
	adc	r8, r8, r4, lsr #28                @ ... pos += step>>28 + carry
	mla	r1, r0, sb, r1                     @ acc += sample * amp
	strh	r1, [r2], #2
	subs	r6, r6, #1
	bpl	.L030068BC                         @ runs n+1 times
	str	r3, [fp, #-0x30]
	b	.L03006A98
.L030068E4:
	ldrb	r3, [lr]
	cmp	r3, #0
	beq	.L03006934
	cmp	r3, #1
	bne	.L03006A98
	cmp	r6, #0
	beq	.L03006A98
	ldr	r3, [fp, #-0x30]
	ldr	r1, [fp, #-0x2c]
.L03006908:
	ldrsb	r0, [r8]
	adds	r3, r3, r4, lsl #4
	adc	r8, r8, r4, lsr #28
	mul	r0, sb, r0                         @ acc = sample * amp
	strh	r0, [r1], #2
	subs	r6, r6, #1
	bpl	.L03006908
	str	r3, [fp, #-0x30]
	b	.L03006A98
.Lw0300692C:
	.word	snd_accum
.Lw03006930:
	.word	snd_voicesMixed
.L03006934:
	lsr	r6, r6, #1
	ldrsh	lr, [r7, #0x14]
	sub	r6, r6, #1
	ldrb	r5, [r7, #0x17]
	cmn	r6, #1
	beq	.L03006A90
	mov	r2, #0x7f0
	add	r2, r2, #0xf
	mov	r3, #0x80000000
	str	r2, [fp, #-0x34]
	asr	r3, r3, #0x14
	str	r3, [fp, #-0x38]
.L03006964:
	ldrb	ip, [r8], #1                      @ next ADPCM byte
	lsl	r3, r5, #5
	ldr	r1, .Lw03006AA8                    @ =adpcm_diffTable
	eor	ip, ip, #0xec                      @ bytes are stored XOR 0xEC
	lsr	r0, ip, #4
	orr	r3, r3, r0, lsl #1
	ldrsh	r2, [r1, r3]                     @ diff = adpcm_diffTable[idx][hi]
	add	lr, lr, r2
	ldr	r2, [fp, #-0x34]
	mvn	r1, #0x800
	ldr	r3, [fp, #-0x38]
	cmp	lr, r2
	movge	lr, r2                           @ clamp to 2047
	cmp	lr, r1
	movle	lr, r3                           @ clamp to -2048
	asr	r4, lr, #3
	mul	r4, sb, r4                         @ (pred >> 3) * amp
	and	r0, r0, #7
	ldr	r2, .Lw03006AAC                    @ =adpcm_nextIndex
	orr	r0, r0, r5, lsl #3
	ldrb	r5, [r2, r0]                      @ idx = adpcm_nextIndex[idx][hi & 7]
	and	r1, ip, #0xf
	lsl	r3, r5, #5
	orr	r3, r3, r1, lsl #1
	ldr	r1, .Lw03006AA8                    @ =adpcm_diffTable
	ldrsh	r2, [r1, r3]                     @ diff for the low nibble
	add	lr, lr, r2
	ldr	r2, [fp, #-0x34]
	ldr	r3, [fp, #-0x2c]
	cmp	lr, r2
	movge	lr, r2
	strh	r4, [r3], #2
	mvn	r2, #0x800
	ldr	r1, [fp, #-0x38]
	cmp	lr, r2
	movle	lr, r1
	asr	r4, lr, #3
	mul	r4, sb, r4
	str	r3, [fp, #-0x2c]
	ldr	r1, [fp, #-0x2c]
	and	ip, ip, #7
	ldr	r3, .Lw03006AAC                    @ =adpcm_nextIndex
	orr	ip, ip, r5, lsl #3
	ldrb	r5, [r3, ip]
	strh	r4, [r1], #2
	str	r1, [fp, #-0x2c]
	cmp	sl, #0
	cmpge	r6, #0
	bne	.L03006A84                         @ block not finished, or not a stream
	ldr	r0, [r7, #0x1c]
	cmp	r0, #0
	beq	.L03006A84
	ldrh	r2, [r7, #0x24]
	ldr	r1, [r7, #0x20]
	add	r3, r2, #1
	lsl	r2, r2, #0x10
	strh	r3, [r7, #0x24]
	asr	r2, r2, #0xf
	ldrsh	r3, [r2, r1]                     @ i = chainOrder[chainIndex++]
	cmn	r3, #1                             @ -1: restart the order list at entry 0
	moveq	r2, #1
	strheq	r2, [r7, #0x24]
	ldrsheq	r3, [r1]
	cmn	r3, #1
	ldr	r3, [r0, r3, lsl #2]
	mov	r6, #0
	movne	r6, sl
	addne	r8, r3, #0x10                    @ pos = new block data
	strne	r3, [r7]
	mvn	sl, #0                             @ over = -1
	mov	lr, #0                             @ reset predictor and step index
	mov	r5, lr
.L03006A84:
	sub	r6, r6, #1
	cmn	r6, #1
	bne	.L03006964
.L03006A90:
	strb	r5, [r7, #0x17]
	strh	lr, [r7, #0x14]
.L03006A98:
	ldr	r3, [fp, #-0x30]
	str	r3, [r7, #0xc]
	str	r8, [r7, #4]
	b	.L03006AB0
.Lw03006AA8:
	.word	adpcm_diffTable
.Lw03006AAC:
	.word	adpcm_nextIndex
.L03006AB0:
	ldmdb	fp, {r4, r5, r6, r7, r8, sb, sl, fp, sp, lr}
	bx	lr

@ ==================== snd_downmix_arm  (03006AB8) ====================
@ void snd_downmix_arm(s8 *dst, int n, int accOffset)    // accum -> ring, 16-bit -> 8-bit
@ {
@     s16 *src = snd_accum + accOffset;
@     if (!dst || !n) return;
@     if (snd_voicesMixed)
@         do { s = *src++ >> 4;  *dst++ = clamp(s, -128, 127); } while (n-- > 0);   // n+1 bytes
@     else
@         memset(dst, 0, n);                             // nothing playing: silence
@ }
	.global snd_downmix_arm
snd_downmix_arm:
	mov	ip, sp
	push	{fp, ip, lr, pc}
	ldr	r3, .Lw03006B4C                    @ =snd_accum
	sub	fp, ip, #4
	mov	ip, r1
	mov	lr, r0
	ldr	r1, [r3]
	cmp	lr, #0
	cmpne	ip, #0
	add	r2, r1, r2, lsl #1
	ldmdbeq	fp, {fp, sp, lr}
	bxeq	lr
	ldr	r3, .Lw03006B50                    @ =snd_voicesMixed
	ldrb	r3, [r3]
	cmp	r3, #0
	beq	.L03006B24
.L03006AF8:
	ldrsh	r0, [r2], #2
	asr	r0, r0, #4                         @ >> 4
	cmn	r0, #0x80
	mvnlt	r0, #0x7f                        @ clamp -128
	cmp	r0, #0x7f
	movgt	r0, #0x7f                        @ clamp 127
	strb	r0, [lr], #1
	subs	ip, ip, #1
	bpl	.L03006AF8                         @ runs n+1 times
	ldmdb	fp, {fp, sp, lr}
	bx	lr
.L03006B24:
	sub	ip, ip, #1
	cmn	ip, #1
	ldmdbeq	fp, {fp, sp, lr}
	bxeq	lr
.L03006B34:
	sub	ip, ip, #1
	strb	r3, [lr], #1                      @ silence
	cmn	ip, #1
	bne	.L03006B34
	ldmdb	fp, {fp, sp, lr}
	bx	lr
.Lw03006B4C:
	.word	snd_accum
.Lw03006B50:
	.word	snd_voicesMixed

@ radriver_data.s -- every RADriver data object in Aggressive Inline (E): sound bank, 30 PCM effects,
@ 16 streamed-music tables and their ADPCM blocks. Payload bytes are pulled in with .incbin from bin/.
	.include "radriver.inc"

@ Sample header (16 bytes). type 0 = 4-bit ADPCM (XOR 0xEC), 1 = 8-bit signed PCM.
@ loopStart = byte offset of the loop point, 0 = one-shot.
	.macro SAMPLE type, length, loopStart
	.byte	\type, 0, 0, 0
	.word	\length, \loopStart, 0
	.endm

@ ======================================================================
@ Range 1: 0x08000284-0x08031690  sound effects and the sound bank
@ Every PCM sample is followed by a 768-byte guard band (silence, or a copy of the loop
@ region for looped samples) so the mixer can run past the end within one frame.
@ ======================================================================
	.section .rodata.radriver_sfx,"a",%progbits
	.balign 4
	.global sfx00
sfx00:					@ 1.62 s at 11025 Hz, loops from byte 4543
	SAMPLE	1, 17839, 4543
	.incbin	"bin/sfx00.pcm"
	.incbin	"bin/sfx00.pcm", 4543, 768		@ guard band = loop continuation
	.space	1
	.global sfx01
sfx01:					@ 0.41 s at 11025 Hz
	SAMPLE	1, 4502, 0
	.incbin	"bin/sfx01.pcm"
	.space	768				@ guard band
	.space	2
	.global sfx02
sfx02:					@ 0.14 s at 11025 Hz
	SAMPLE	1, 1578, 0
	.incbin	"bin/sfx02.pcm"
	.space	768				@ guard band
	.space	2
	.global sfx03
sfx03:					@ 0.39 s at 11025 Hz
	SAMPLE	1, 4272, 0
	.incbin	"bin/sfx03.pcm"
	.space	768				@ guard band
	.global sfx04
sfx04:					@ 0.45 s at 11025 Hz
	SAMPLE	1, 4927, 0
	.incbin	"bin/sfx04.pcm"
	.space	768				@ guard band
	.space	1
	.global sfx05
sfx05:					@ 0.75 s at 11025 Hz
	SAMPLE	1, 8225, 0
	.incbin	"bin/sfx05.pcm"
	.space	768				@ guard band
	.space	3
	.global sfx06
sfx06:					@ 0.67 s at 11025 Hz
	SAMPLE	1, 7392, 0
	.incbin	"bin/sfx06.pcm"
	.space	768				@ guard band
	.global sfx07
sfx07:					@ 0.80 s at 11025 Hz
	SAMPLE	1, 8782, 0
	.incbin	"bin/sfx07.pcm"
	.space	768				@ guard band
	.space	2
	.global sfx08
sfx08:					@ 0.26 s at 11025 Hz
	SAMPLE	1, 2848, 0
	.incbin	"bin/sfx08.pcm"
	.space	768				@ guard band
	.global sfx09
sfx09:					@ 0.77 s at 11025 Hz
	SAMPLE	1, 8445, 0
	.incbin	"bin/sfx09.pcm"
	.space	768				@ guard band
	.space	3
	.global sfx10
sfx10:					@ 0.68 s at 11025 Hz
	SAMPLE	1, 7545, 0
	.incbin	"bin/sfx10.pcm"
	.space	768				@ guard band
	.space	3
	.global sfx11
sfx11:					@ 1.26 s at 11025 Hz
	SAMPLE	1, 13927, 0
	.incbin	"bin/sfx11.pcm"
	.space	768				@ guard band
	.space	1
	.global sfx12
sfx12:					@ 0.28 s at 11025 Hz
	SAMPLE	1, 3107, 0
	.incbin	"bin/sfx12.pcm"
	.space	768				@ guard band
	.space	1
	.global sfx13
sfx13:					@ 0.31 s at 11025 Hz
	SAMPLE	1, 3456, 0
	.incbin	"bin/sfx13.pcm"
	.space	768				@ guard band
	.global sfx14
sfx14:					@ 1.02 s at 11025 Hz
	SAMPLE	1, 11262, 0
	.incbin	"bin/sfx14.pcm"
	.space	768				@ guard band
	.space	2
	.global sfx15
sfx15:					@ 0.40 s at 11025 Hz
	SAMPLE	1, 4410, 0
	.incbin	"bin/sfx15.pcm"
	.space	768				@ guard band
	.space	2
	.global sfx16
sfx16:					@ 0.38 s at 11025 Hz
	SAMPLE	1, 4167, 0
	.incbin	"bin/sfx16.pcm"
	.space	768				@ guard band
	.space	1
	.global sfx17
sfx17:					@ 0.31 s at 11025 Hz
	SAMPLE	1, 3384, 0
	.incbin	"bin/sfx17.pcm"
	.space	768				@ guard band
	.global sfx18
sfx18:					@ 0.31 s at 11025 Hz
	SAMPLE	1, 3424, 0
	.incbin	"bin/sfx18.pcm"
	.space	768				@ guard band
	.global sfx19
sfx19:					@ 0.35 s at 11025 Hz
	SAMPLE	1, 3808, 0
	.incbin	"bin/sfx19.pcm"
	.space	768				@ guard band
	.global sfx20
sfx20:					@ 0.20 s at 11025 Hz
	SAMPLE	1, 2168, 0
	.incbin	"bin/sfx20.pcm"
	.space	768				@ guard band
	.global sfx21
sfx21:					@ 0.45 s at 11025 Hz
	SAMPLE	1, 4934, 0
	.incbin	"bin/sfx21.pcm"
	.space	768				@ guard band
	.space	2
	.global sfx22
sfx22:					@ 1.00 s at 11025 Hz
	SAMPLE	1, 10992, 0
	.incbin	"bin/sfx22.pcm"
	.space	768				@ guard band
	.global sfx23
sfx23:					@ 0.33 s at 11025 Hz
	SAMPLE	1, 3646, 0
	.incbin	"bin/sfx23.pcm"
	.space	768				@ guard band
	.space	2
	.global sfx24
sfx24:					@ 0.60 s at 11025 Hz
	SAMPLE	1, 6596, 0
	.incbin	"bin/sfx24.pcm"
	.space	768				@ guard band
	.global sfx25
sfx25:					@ 0.63 s at 11025 Hz
	SAMPLE	1, 6906, 0
	.incbin	"bin/sfx25.pcm"
	.space	768				@ guard band
	.space	2
	.global sfx26
sfx26:					@ 0.35 s at 11025 Hz
	SAMPLE	1, 3811, 0
	.incbin	"bin/sfx26.pcm"
	.space	768				@ guard band
	.space	1
	.global sfx27
sfx27:					@ 0.57 s at 11025 Hz
	SAMPLE	1, 6297, 0
	.incbin	"bin/sfx27.pcm"
	.space	768				@ guard band
	.space	3
	.global sfx28
sfx28:					@ 0.26 s at 11025 Hz
	SAMPLE	1, 2896, 0
	.incbin	"bin/sfx28.pcm"
	.space	768				@ guard band
	.global sfx29
sfx29:					@ 0.23 s at 11025 Hz
	SAMPLE	1, 2503, 0
	.incbin	"bin/sfx29.pcm"
	.space	768				@ guard band
	.space	1

@ Bank: {songCount, sampleCount, songs, samples}. No sequenced songs here, so songs == samples.
	.global snd_bankAI
snd_bankAI:
	.word	0, 30, sfxTable, sfxTable
sfxTable:
	.word	sfx00
	.word	sfx01
	.word	sfx02
	.word	sfx03
	.word	sfx04
	.word	sfx05
	.word	sfx06
	.word	sfx07
	.word	sfx08
	.word	sfx09
	.word	sfx10
	.word	sfx11
	.word	sfx12
	.word	sfx13
	.word	sfx14
	.word	sfx15
	.word	sfx16
	.word	sfx17
	.word	sfx18
	.word	sfx19
	.word	sfx20
	.word	sfx21
	.word	sfx22
	.word	sfx23
	.word	sfx24
	.word	sfx25
	.word	sfx26
	.word	sfx27
	.word	sfx28
	.word	sfx29

@ ======================================================================
@ Range 2: 0x080690A4-0x0806AF5C  streamed-music block tables, order lists and the stream table
@ order lists are s16 block indices ending in -1 (the mixer then restarts the list).
@ ======================================================================
	.section .rodata.radriver_streams,"a",%progbits
	.balign 4
stream02_blocks:
	.word	s02_b00
	.word	s02_b01
	.word	s02_b02
	.word	s02_b03
	.word	s02_b04
stream02_order:				@ 89 entries + terminator
	.hword	1, 2, 3, 2, 3, 2, 3, 2, 4, 0, 0, 0, 0, 0, 0, 0
	.hword	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
	.hword	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
	.hword	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
	.hword	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
	.hword	0, 0, 0, 0, 0, 0, 0, 0, 0, -1
stream13_blocks:
	.word	s13_b00
	.word	s13_b01
	.word	s13_b02
	.word	s13_b03
	.word	s13_b04
	.word	s13_b05
	.word	s13_b06
stream13_order:				@ 14 entries + terminator
	.hword	0, 2, 0, 1, 6, 3, 4, 0, 2, 0, 1, 6, 5, 4, -1
	.space	2
stream03_blocks:
	.word	s03_b00
	.word	s03_b01
	.word	s03_b02
	.word	s03_b03
	.word	s03_b04
	.word	s03_b05
	.word	s03_b06
	.word	s03_b07
	.word	s03_b08
	.word	s03_b09
	.word	s03_b10
	.word	s03_b11
stream03_order:				@ 31 entries + terminator
	.hword	1, 1, 1, 1, 2, 3, 2, 3, 2, 3, 2, 4, 5, 11, 0, 6
	.hword	7, 6, 8, 5, 0, 6, 7, 6, 8, 9, 10, 6, 7, 6, 8, -1
stream06_blocks:
	.word	s06_b00
	.word	s06_b01
	.word	s06_b02
	.word	s06_b03
	.word	s06_b04
	.word	s06_b05
	.word	s06_b06
	.word	s06_b07
	.word	s06_b08
	.word	s06_b09
	.word	s06_b10
	.word	s06_b11
stream06_order:				@ 74 entries + terminator
	.hword	1, 1, 1, 2, 10, 3, 5, 10, 3, 4, 10, 3, 5, 10, 3, 4
	.hword	6, 7, 6, 8, 6, 7, 6, 8, 9, 3, 5, 9, 3, 4, 9, 3
	.hword	5, 9, 3, 4, 6, 7, 6, 8, 6, 7, 6, 8, 11, 0, 11, 0
	.hword	11, 11, 0, 11, 0, 11, 11, 0, 11, 0, 11, 11, 0, 11, 0, 11
	.hword	10, 3, 5, 10, 3, 4, 10, 10, 10, 10, -1
	.space	2
stream01_blocks:
	.word	s01_b00
	.word	s01_b01
	.word	s01_b02
	.word	s01_b03
	.word	s01_b04
	.word	s01_b05
	.word	s01_b06
	.word	s01_b07
	.word	s01_b08
	.word	s01_b09
	.word	s01_b10
	.word	s01_b11
	.word	s01_b12
	.word	s01_b13
	.word	s01_b14
	.word	s01_b15
	.word	s01_b16
stream01_order:				@ 1000 entries + terminator
	.hword	0, 0, 0, 1, 2, 3, 2, 3, 2, 4, 5, 6, 8, 9, 10, 10
	.hword	11, 12, 13, 10, 11, 12, 9, 10, 10, 11, 12, 13, 14, 15, 14, 16
	.hword	14, 15, 14, 16, 6, 7, 5, 6, 8, 9, 10, 11, 12, 9, 10, 10
	.hword	11, 12, 13, 14, 15, 14, 16, 14, 15, 14, 16, 6, 7, 2, 3, 2
	.hword	4, 5, 6, 8, 9, 10, 10, 11, 12, 13, 10, 11, 12, 9, 10, 10
	.hword	11, 12, 13, 14, 15, 14, 16, 14, 15, 14, 16, 6, 7, 5, 6, 8
	.hword	9, 10, 11, 12, 9, 10, 10, 11, 12, 13, 14, 15, 14, 16, 14, 15
	.hword	14, 16, 6, 7, 2, 3, 2, 4, 5, 6, 8, 9, 10, 10, 11, 12
	.hword	13, 10, 11, 12, 9, 10, 10, 11, 12, 13, 14, 15, 14, 16, 14, 15
	.hword	14, 16, 6, 7, 5, 6, 8, 9, 10, 11, 12, 9, 10, 10, 11, 12
	.hword	13, 14, 15, 14, 16, 14, 15, 14, 16, 6, 7, 2, 3, 2, 4, 5
	.hword	6, 8, 9, 10, 10, 11, 12, 13, 10, 11, 12, 9, 10, 10, 11, 12
	.hword	13, 14, 15, 14, 16, 14, 15, 14, 16, 6, 7, 5, 6, 8, 9, 10
	.hword	11, 12, 9, 10, 10, 11, 12, 13, 14, 15, 14, 16, 14, 15, 14, 16
	.hword	6, 7, 2, 3, 2, 4, 5, 6, 8, 9, 10, 10, 11, 12, 13, 10
	.hword	11, 12, 9, 10, 10, 11, 12, 13, 14, 15, 14, 16, 14, 15, 14, 16
	.hword	6, 7, 5, 6, 8, 9, 10, 11, 12, 9, 10, 10, 11, 12, 13, 14
	.hword	15, 14, 16, 14, 15, 14, 16, 6, 7, 2, 3, 2, 4, 5, 6, 8
	.hword	9, 10, 10, 11, 12, 13, 10, 11, 12, 9, 10, 10, 11, 12, 13, 14
	.hword	15, 14, 16, 14, 15, 14, 16, 6, 7, 5, 6, 8, 9, 10, 11, 12
	.hword	9, 10, 10, 11, 12, 13, 14, 15, 14, 16, 14, 15, 14, 16, 6, 7
	.hword	2, 3, 2, 4, 5, 6, 8, 9, 10, 10, 11, 12, 13, 10, 11, 12
	.hword	9, 10, 10, 11, 12, 13, 14, 15, 14, 16, 14, 15, 14, 16, 6, 7
	.hword	5, 6, 8, 9, 10, 11, 12, 9, 10, 10, 11, 12, 13, 14, 15, 14
	.hword	16, 14, 15, 14, 16, 6, 7, 2, 3, 2, 4, 5, 6, 8, 9, 10
	.hword	10, 11, 12, 13, 10, 11, 12, 9, 10, 10, 11, 12, 13, 14, 15, 14
	.hword	16, 14, 15, 14, 16, 6, 7, 5, 6, 8, 9, 10, 11, 12, 9, 10
	.hword	10, 11, 12, 13, 14, 15, 14, 16, 14, 15, 14, 16, 6, 7, 2, 3
	.hword	2, 4, 5, 6, 8, 9, 10, 10, 11, 12, 13, 10, 11, 12, 9, 10
	.hword	10, 11, 12, 13, 14, 15, 14, 16, 14, 15, 14, 16, 6, 7, 5, 6
	.hword	8, 9, 10, 11, 12, 9, 10, 10, 11, 12, 13, 14, 15, 14, 16, 14
	.hword	15, 14, 16, 6, 7, 2, 3, 2, 4, 5, 6, 8, 9, 10, 10, 11
	.hword	12, 13, 10, 11, 12, 9, 10, 10, 11, 12, 13, 14, 15, 14, 16, 14
	.hword	15, 14, 16, 6, 7, 5, 6, 8, 9, 10, 11, 12, 9, 10, 10, 11
	.hword	12, 13, 14, 15, 14, 16, 14, 15, 14, 16, 6, 7, 2, 3, 2, 4
	.hword	5, 6, 8, 9, 10, 10, 11, 12, 13, 10, 11, 12, 9, 10, 10, 11
	.hword	12, 13, 14, 15, 14, 16, 14, 15, 14, 16, 6, 7, 5, 6, 8, 9
	.hword	10, 11, 12, 9, 10, 10, 11, 12, 13, 14, 15, 14, 16, 14, 15, 14
	.hword	16, 6, 7, 2, 3, 2, 4, 5, 6, 8, 9, 10, 10, 11, 12, 13
	.hword	10, 11, 12, 9, 10, 10, 11, 12, 13, 14, 15, 14, 16, 14, 15, 14
	.hword	16, 6, 7, 5, 6, 8, 9, 10, 11, 12, 9, 10, 10, 11, 12, 13
	.hword	14, 15, 14, 16, 14, 15, 14, 16, 6, 7, 2, 3, 2, 4, 5, 6
	.hword	8, 9, 10, 10, 11, 12, 13, 10, 11, 12, 9, 10, 10, 11, 12, 13
	.hword	14, 15, 14, 16, 14, 15, 14, 16, 6, 7, 5, 6, 8, 9, 10, 11
	.hword	12, 9, 10, 10, 11, 12, 13, 14, 15, 14, 16, 14, 15, 14, 16, 6
	.hword	7, 2, 3, 2, 4, 5, 6, 8, 9, 10, 10, 11, 12, 13, 10, 11
	.hword	12, 9, 10, 10, 11, 12, 13, 14, 15, 14, 16, 14, 15, 14, 16, 6
	.hword	7, 5, 6, 8, 9, 10, 11, 12, 9, 10, 10, 11, 12, 13, 14, 15
	.hword	14, 16, 14, 15, 14, 16, 6, 7, 2, 3, 2, 4, 5, 6, 8, 9
	.hword	10, 10, 11, 12, 13, 10, 11, 12, 9, 10, 10, 11, 12, 13, 14, 15
	.hword	14, 16, 14, 15, 14, 16, 6, 7, 5, 6, 8, 9, 10, 11, 12, 9
	.hword	10, 10, 11, 12, 13, 14, 15, 14, 16, 14, 15, 14, 16, 6, 7, 2
	.hword	3, 2, 4, 5, 6, 8, 9, 10, 10, 11, 12, 13, 10, 11, 12, 9
	.hword	10, 10, 11, 12, 13, 14, 15, 14, 16, 14, 15, 14, 16, 6, 7, 5
	.hword	6, 8, 9, 10, 11, 12, 9, 10, 10, 11, 12, 13, 14, 15, 14, 16
	.hword	14, 15, 14, 16, 6, 7, 2, 3, 2, 4, 5, 6, 8, 9, 10, 10
	.hword	11, 12, 13, 10, 11, 12, 9, 10, 10, 11, 12, 13, 14, 15, 14, 16
	.hword	14, 15, 14, 16, 6, 7, 5, 6, 8, 9, 10, 11, 12, 9, 10, 10
	.hword	11, 12, 13, 14, 15, 14, 16, 14, 15, 14, 16, 6, 7, 2, 3, 2
	.hword	4, 5, 6, 8, 9, 10, 10, 11, 12, 13, 10, 11, 12, 9, 10, 10
	.hword	11, 12, 13, 14, 15, 14, 16, 14, 15, 14, 16, 6, 7, 5, 6, 8
	.hword	9, 10, 11, 12, 9, 10, 10, 11, 12, 13, 14, 15, 14, 16, 14, 15
	.hword	14, 16, 6, 7, 2, 3, 2, 4, -1
	.space	2
stream08_blocks:
	.word	s08_b00
	.word	s08_b01
	.word	s08_b02
	.word	s08_b03
	.word	s08_b04
	.word	s08_b05
	.word	s08_b06
	.word	s08_b07
	.word	s08_b08
	.word	s08_b09
	.word	s08_b10
stream08_order:				@ 836 entries + terminator
	.hword	0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 3, 2, 2, 3, 2, 2
	.hword	3, 2, 2, 3, 4, 4, 5, 4, 4, 5, 2, 2, 3, 2, 2, 3
	.hword	6, 6, 6, 6, 7, 7, 6, 6, 8, 9, 8, 10, 8, 9, 8, 10
	.hword	6, 6, 6, 6, 7, 7, 6, 6, 1, 1, 1, 1, 2, 2, 3, 2
	.hword	2, 3, 2, 2, 3, 2, 2, 3, 4, 4, 5, 4, 4, 5, 2, 2
	.hword	3, 2, 2, 3, 6, 6, 6, 6, 7, 7, 6, 6, 8, 9, 8, 10
	.hword	8, 9, 8, 10, 6, 6, 6, 6, 7, 7, 6, 6, 1, 1, 1, 1
	.hword	2, 2, 3, 2, 2, 3, 2, 2, 3, 2, 2, 3, 4, 4, 5, 4
	.hword	4, 5, 2, 2, 3, 2, 2, 3, 6, 6, 6, 6, 7, 7, 6, 6
	.hword	8, 9, 8, 10, 8, 9, 8, 10, 6, 6, 6, 6, 7, 7, 6, 6
	.hword	1, 1, 1, 1, 2, 2, 3, 2, 2, 3, 2, 2, 3, 2, 2, 3
	.hword	4, 4, 5, 4, 4, 5, 2, 2, 3, 2, 2, 3, 6, 6, 6, 6
	.hword	7, 7, 6, 6, 8, 9, 8, 10, 8, 9, 8, 10, 6, 6, 6, 6
	.hword	7, 7, 6, 6, 1, 1, 1, 1, 2, 2, 3, 2, 2, 3, 2, 2
	.hword	3, 2, 2, 3, 4, 4, 5, 4, 4, 5, 2, 2, 3, 2, 2, 3
	.hword	6, 6, 6, 6, 7, 7, 6, 6, 8, 9, 8, 10, 8, 9, 8, 10
	.hword	6, 6, 6, 6, 7, 7, 6, 6, 1, 1, 1, 1, 2, 2, 3, 2
	.hword	2, 3, 2, 2, 3, 2, 2, 3, 4, 4, 5, 4, 4, 5, 2, 2
	.hword	3, 2, 2, 3, 6, 6, 6, 6, 7, 7, 6, 6, 8, 9, 8, 10
	.hword	8, 9, 8, 10, 6, 6, 6, 6, 7, 7, 6, 6, 1, 1, 1, 1
	.hword	2, 2, 3, 2, 2, 3, 2, 2, 3, 2, 2, 3, 4, 4, 5, 4
	.hword	4, 5, 2, 2, 3, 2, 2, 3, 6, 6, 6, 6, 7, 7, 6, 6
	.hword	8, 9, 8, 10, 8, 9, 8, 10, 6, 6, 6, 6, 7, 7, 6, 6
	.hword	1, 1, 1, 1, 2, 2, 3, 2, 2, 3, 2, 2, 3, 2, 2, 3
	.hword	4, 4, 5, 4, 4, 5, 2, 2, 3, 2, 2, 3, 6, 6, 6, 6
	.hword	7, 7, 6, 6, 8, 9, 8, 10, 8, 9, 8, 10, 6, 6, 6, 6
	.hword	7, 7, 6, 6, 1, 1, 1, 1, 2, 2, 3, 2, 2, 3, 2, 2
	.hword	3, 2, 2, 3, 4, 4, 5, 4, 4, 5, 2, 2, 3, 2, 2, 3
	.hword	6, 6, 6, 6, 7, 7, 6, 6, 8, 9, 8, 10, 8, 9, 8, 10
	.hword	6, 6, 6, 6, 7, 7, 6, 6, 1, 1, 1, 1, 2, 2, 3, 2
	.hword	2, 3, 2, 2, 3, 2, 2, 3, 4, 4, 5, 4, 4, 5, 2, 2
	.hword	3, 2, 2, 3, 6, 6, 6, 6, 7, 7, 6, 6, 8, 9, 8, 10
	.hword	8, 9, 8, 10, 6, 6, 6, 6, 7, 7, 6, 6, 1, 1, 1, 1
	.hword	2, 2, 3, 2, 2, 3, 2, 2, 3, 2, 2, 3, 4, 4, 5, 4
	.hword	4, 5, 2, 2, 3, 2, 2, 3, 6, 6, 6, 6, 7, 7, 6, 6
	.hword	8, 9, 8, 10, 8, 9, 8, 10, 6, 6, 6, 6, 7, 7, 6, 6
	.hword	1, 1, 1, 1, 2, 2, 3, 2, 2, 3, 2, 2, 3, 2, 2, 3
	.hword	4, 4, 5, 4, 4, 5, 2, 2, 3, 2, 2, 3, 6, 6, 6, 6
	.hword	7, 7, 6, 6, 8, 9, 8, 10, 8, 9, 8, 10, 6, 6, 6, 6
	.hword	7, 7, 6, 6, 1, 1, 1, 1, 2, 2, 3, 2, 2, 3, 2, 2
	.hword	3, 2, 2, 3, 4, 4, 5, 4, 4, 5, 2, 2, 3, 2, 2, 3
	.hword	6, 6, 6, 6, 7, 7, 6, 6, 8, 9, 8, 10, 8, 9, 8, 10
	.hword	6, 6, 6, 6, 7, 7, 6, 6, 1, 1, 1, 1, 2, 2, 3, 2
	.hword	2, 3, 2, 2, 3, 2, 2, 3, 4, 4, 5, 4, 4, 5, 2, 2
	.hword	3, 2, 2, 3, 6, 6, 6, 6, 7, 7, 6, 6, 8, 9, 8, 10
	.hword	8, 9, 8, 10, 6, 6, 6, 6, 7, 7, 6, 6, 1, 1, 1, 1
	.hword	2, 2, 3, 2, 2, 3, 2, 2, 3, 2, 2, 3, 4, 4, 5, 4
	.hword	4, 5, 2, 2, 3, 2, 2, 3, 6, 6, 6, 6, 7, 7, 6, 6
	.hword	8, 9, 8, 10, 8, 9, 8, 10, 6, 6, 6, 6, 7, 7, 6, 6
	.hword	1, 1, 1, 1, 2, 2, 3, 2, 2, 3, 2, 2, 3, 2, 2, 3
	.hword	4, 4, 5, 4, 4, 5, 2, 2, 3, 2, 2, 3, 6, 6, 6, 6
	.hword	7, 7, 6, 6, 8, 9, 8, 10, 8, 9, 8, 10, 6, 6, 6, 6
	.hword	7, 7, 6, 6, -1
	.space	2
stream07_blocks:
	.word	s07_b00
	.word	s07_b01
	.word	s07_b02
	.word	s07_b03
	.word	s07_b04
	.word	s07_b05
	.word	s07_b06
	.word	s07_b07
	.word	s07_b08
stream07_order:				@ 52 entries + terminator
	.hword	0, 1, 0, 2, 6, 3, 6, 3, 6, 3, 6, 3, 4, 4, 4, 5
	.hword	4, 4, 4, 5, 6, 3, 6, 3, 6, 3, 6, 3, 4, 4, 4, 5
	.hword	4, 4, 4, 5, 6, 7, 6, 7, 6, 7, 6, 7, 6, 8, 6, 8
	.hword	6, 8, 6, 8, -1
	.space	2
stream10_blocks:
	.word	s10_b00
	.word	s10_b01
	.word	s10_b02
stream10_order:				@ 144 entries + terminator
	.hword	1, 0, 2, 0, 2, 0, 2, 0, 1, 0, 2, 0, 2, 0, 2, 0
	.hword	1, 0, 2, 0, 2, 0, 2, 0, 1, 0, 2, 0, 2, 0, 2, 0
	.hword	1, 0, 2, 0, 2, 0, 2, 0, 1, 0, 2, 0, 2, 0, 2, 0
	.hword	1, 0, 2, 0, 2, 0, 2, 0, 1, 0, 2, 0, 2, 0, 2, 0
	.hword	1, 0, 2, 0, 2, 0, 2, 0, 1, 0, 2, 0, 2, 0, 2, 0
	.hword	1, 0, 2, 0, 2, 0, 2, 0, 1, 0, 2, 0, 2, 0, 2, 0
	.hword	1, 0, 2, 0, 2, 0, 2, 0, 1, 0, 2, 0, 2, 0, 2, 0
	.hword	1, 0, 2, 0, 2, 0, 2, 0, 1, 0, 2, 0, 2, 0, 2, 0
	.hword	1, 0, 2, 0, 2, 0, 2, 0, 1, 0, 2, 0, 2, 0, 2, 0
	.hword	-1
	.space	2
stream04_blocks:
	.word	s04_b00
	.word	s04_b01
	.word	s04_b02
	.word	s04_b03
	.word	s04_b04
	.word	s04_b05
	.word	s04_b06
	.word	s04_b07
	.word	s04_b08
	.word	s04_b09
	.word	s04_b10
	.word	s04_b11
	.word	s04_b12
	.word	s04_b13
	.word	s04_b14
	.word	s04_b15
	.word	s04_b16
stream04_order:				@ 953 entries + terminator
	.hword	1, 0, 2, 1, 0, 2, 1, 0, 2, 1, 0, 3, 16, 4, 5, 16
	.hword	4, 6, 7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13
	.hword	14, 13, 15, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9, 7, 11
	.hword	10, 7, 12, 13, 14, 13, 14, 13, 15, 0, 2, 1, 0, 2, 1, 0
	.hword	2, 1, 0, 3, 16, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9
	.hword	7, 11, 10, 7, 12, 13, 14, 13, 14, 13, 15, 4, 5, 16, 4, 6
	.hword	7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13, 14, 13
	.hword	15, 0, 2, 1, 0, 2, 1, 0, 2, 1, 0, 3, 16, 4, 5, 16
	.hword	4, 6, 7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13
	.hword	14, 13, 15, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9, 7, 11
	.hword	10, 7, 12, 13, 14, 13, 14, 13, 15, 0, 2, 1, 0, 2, 1, 0
	.hword	2, 1, 0, 3, 16, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9
	.hword	7, 11, 10, 7, 12, 13, 14, 13, 14, 13, 15, 4, 5, 16, 4, 6
	.hword	7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13, 14, 13
	.hword	15, 0, 2, 1, 0, 2, 1, 0, 2, 1, 0, 3, 16, 4, 5, 16
	.hword	4, 6, 7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13
	.hword	14, 13, 15, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9, 7, 11
	.hword	10, 7, 12, 13, 14, 13, 14, 13, 15, 0, 2, 1, 0, 2, 1, 0
	.hword	2, 1, 0, 3, 16, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9
	.hword	7, 11, 10, 7, 12, 13, 14, 13, 14, 13, 15, 4, 5, 16, 4, 6
	.hword	7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13, 14, 13
	.hword	15, 0, 2, 1, 0, 2, 1, 0, 2, 1, 0, 3, 16, 4, 5, 16
	.hword	4, 6, 7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13
	.hword	14, 13, 15, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9, 7, 11
	.hword	10, 7, 12, 13, 14, 13, 14, 13, 15, 0, 2, 1, 0, 2, 1, 0
	.hword	2, 1, 0, 3, 16, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9
	.hword	7, 11, 10, 7, 12, 13, 14, 13, 14, 13, 15, 4, 5, 16, 4, 6
	.hword	7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13, 14, 13
	.hword	15, 0, 2, 1, 0, 2, 1, 0, 2, 1, 0, 3, 16, 4, 5, 16
	.hword	4, 6, 7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13
	.hword	14, 13, 15, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9, 7, 11
	.hword	10, 7, 12, 13, 14, 13, 14, 13, 15, 0, 2, 1, 0, 2, 1, 0
	.hword	2, 1, 0, 3, 16, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9
	.hword	7, 11, 10, 7, 12, 13, 14, 13, 14, 13, 15, 4, 5, 16, 4, 6
	.hword	7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13, 14, 13
	.hword	15, 0, 2, 1, 0, 2, 1, 0, 2, 1, 0, 3, 16, 4, 5, 16
	.hword	4, 6, 7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13
	.hword	14, 13, 15, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9, 7, 11
	.hword	10, 7, 12, 13, 14, 13, 14, 13, 15, 0, 2, 1, 0, 2, 1, 0
	.hword	2, 1, 0, 3, 16, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9
	.hword	7, 11, 10, 7, 12, 13, 14, 13, 14, 13, 15, 4, 5, 16, 4, 6
	.hword	7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13, 14, 13
	.hword	15, 0, 2, 1, 0, 2, 1, 0, 2, 1, 0, 3, 16, 4, 5, 16
	.hword	4, 6, 7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13
	.hword	14, 13, 15, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9, 7, 11
	.hword	10, 7, 12, 13, 14, 13, 14, 13, 15, 0, 2, 1, 0, 2, 1, 0
	.hword	2, 1, 0, 3, 16, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9
	.hword	7, 11, 10, 7, 12, 13, 14, 13, 14, 13, 15, 4, 5, 16, 4, 6
	.hword	7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13, 14, 13
	.hword	15, 0, 2, 1, 0, 2, 1, 0, 2, 1, 0, 3, 16, 4, 5, 16
	.hword	4, 6, 7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13
	.hword	14, 13, 15, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9, 7, 11
	.hword	10, 7, 12, 13, 14, 13, 14, 13, 15, 0, 2, 1, 0, 2, 1, 0
	.hword	2, 1, 0, 3, 16, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9
	.hword	7, 11, 10, 7, 12, 13, 14, 13, 14, 13, 15, 4, 5, 16, 4, 6
	.hword	7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13, 14, 13
	.hword	15, 0, 2, 1, 0, 2, 1, 0, 2, 1, 0, 3, 16, 4, 5, 16
	.hword	4, 6, 7, 11, 8, 7, 11, 9, 7, 11, 10, 7, 12, 13, 14, 13
	.hword	14, 13, 15, 4, 5, 16, 4, 6, 7, 11, 8, 7, 11, 9, 7, 11
	.hword	10, 7, 12, 13, 14, 13, 14, 13, 15, -1
stream05_blocks:
	.word	s05_b00
	.word	s05_b01
	.word	s05_b02
	.word	s05_b03
	.word	s05_b04
	.word	s05_b05
	.word	s05_b06
	.word	s05_b07
	.word	s05_b08
	.word	s05_b09
	.word	s05_b10
stream05_order:				@ 44 entries + terminator
	.hword	1, 1, 1, 1, 2, 3, 2, 4, 2, 3, 2, 4, 5, 5, 1, 1
	.hword	1, 1, 2, 3, 2, 4, 2, 3, 2, 4, 5, 5, 6, 7, 6, 8
	.hword	6, 7, 6, 8, 9, 10, 9, 0, 9, 10, 9, 0, -1
	.space	2
stream09_blocks:
	.word	s09_b00
	.word	s09_b01
	.word	s09_b02
	.word	s09_b03
	.word	s09_b04
	.word	s09_b05
	.word	s09_b06
	.word	s09_b07
	.word	s09_b08
	.word	s09_b09
	.word	s09_b10
	.word	s09_b11
	.word	s09_b12
	.word	s09_b13
stream09_order:				@ 55 entries + terminator
	.hword	1, 2, 1, 3, 4, 5, 4, 6, 7, 8, 7, 8, 9, 12, 10, 9
	.hword	12, 11, 9, 12, 10, 9, 12, 11, 4, 5, 4, 6, 7, 8, 8, 8
	.hword	9, 12, 10, 9, 12, 11, 9, 12, 10, 9, 13, 0, 0, 0, 0, 0
	.hword	0, 0, 0, 0, 0, 0, 0, -1
stream00_blocks:
	.word	s00_b00
	.word	s00_b01
	.word	s00_b02
	.word	s00_b03
	.word	s00_b04
stream00_order:				@ 174 entries + terminator
	.hword	0, 0, 0, 0, 1, 2, 1, 2, 1, 2, 1, 3, 1, 2, 1, 2
	.hword	1, 2, 1, 3, 4, 1, 2, 1, 2, 1, 2, 1, 3, 1, 2, 1
	.hword	2, 1, 2, 1, 3, 4, 1, 2, 1, 2, 1, 2, 1, 3, 1, 2
	.hword	1, 2, 1, 2, 1, 3, 4, 1, 2, 1, 2, 1, 2, 1, 3, 1
	.hword	2, 1, 2, 1, 2, 1, 3, 4, 1, 2, 1, 2, 1, 2, 1, 3
	.hword	1, 2, 1, 2, 1, 2, 1, 3, 4, 1, 2, 1, 2, 1, 2, 1
	.hword	3, 1, 2, 1, 2, 1, 2, 1, 3, 4, 1, 2, 1, 2, 1, 2
	.hword	1, 3, 1, 2, 1, 2, 1, 2, 1, 3, 4, 1, 2, 1, 2, 1
	.hword	2, 1, 3, 1, 2, 1, 2, 1, 2, 1, 3, 4, 1, 2, 1, 2
	.hword	1, 2, 1, 3, 1, 2, 1, 2, 1, 2, 1, 3, 4, 1, 2, 1
	.hword	2, 1, 2, 1, 3, 1, 2, 1, 2, 1, 2, 1, 3, 4, -1
	.space	2
stream12_blocks:
	.word	s12_b00
stream12_order:				@ 1 entries + terminator
	.hword	0, -1
stream14_blocks:
	.word	s14_b00
	.word	s14_b01
	.word	s14_b02
	.word	s14_b03
	.word	s14_b04
stream14_order:				@ 24 entries + terminator
	.hword	1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 3, 1, 3
	.hword	1, 3, 1, 3, 4, 4, 0, 0, -1
	.space	2
stream15_blocks:
	.word	s15_b00
	.word	s15_b01
stream15_order:				@ 91 entries + terminator
	.hword	0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
	.hword	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
	.hword	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
	.hword	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
	.hword	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
	.hword	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1

@ Stream table indexed by the game's playMusic(n): {blocks, order}
	.global snd_streamTableAI
snd_streamTableAI:
	.word	stream00_blocks, stream00_order	@ stream 0
	.word	stream01_blocks, stream01_order	@ stream 1
	.word	stream02_blocks, stream02_order	@ stream 2
	.word	stream03_blocks, stream03_order	@ stream 3
	.word	stream04_blocks, stream04_order	@ stream 4
	.word	stream05_blocks, stream05_order	@ stream 5
	.word	stream06_blocks, stream06_order	@ stream 6
	.word	stream07_blocks, stream07_order	@ stream 7
	.word	stream08_blocks, stream08_order	@ stream 8
	.word	stream09_blocks, stream09_order	@ stream 9
	.word	stream10_blocks, stream10_order	@ stream 10
	.word	stream10_blocks, stream10_order	@ stream 11 (same data as stream 10)
	.word	stream12_blocks, stream12_order	@ stream 12
	.word	stream13_blocks, stream13_order	@ stream 13
	.word	stream14_blocks, stream14_order	@ stream 14
	.word	stream15_blocks, stream15_order	@ stream 15

@ ======================================================================
@ Range 3: 0x0806DDC0-0x082DF502  ADPCM music blocks (type 0, no guard band: the mixer clamps)
@ ======================================================================
	.section .rodata.radriver_blocks,"a",%progbits
	.balign 4
s02_b00:					@ 297720 bytes = 595440 samples = 54.01 s
	SAMPLE	0, 297720, 0
	.incbin	"bin/s02_b00.adpcm"
s02_b01:					@ 33121 bytes = 66242 samples = 6.01 s
	SAMPLE	0, 33121, 0
	.incbin	"bin/s02_b01.adpcm"
	.space	3
s02_b02:					@ 12384 bytes = 24768 samples = 2.25 s
	SAMPLE	0, 12384, 0
	.incbin	"bin/s02_b02.adpcm"
s02_b03:					@ 4096 bytes = 8192 samples = 0.74 s
	SAMPLE	0, 4096, 0
	.incbin	"bin/s02_b03.adpcm"
s02_b04:					@ 3968 bytes = 7936 samples = 0.72 s
	SAMPLE	0, 3968, 0
	.incbin	"bin/s02_b04.adpcm"
s13_b00:					@ 13047 bytes = 26094 samples = 2.37 s
	SAMPLE	0, 13047, 0
	.incbin	"bin/s13_b00.adpcm"
	.space	1
s13_b01:					@ 13180 bytes = 26360 samples = 2.39 s
	SAMPLE	0, 13180, 0
	.incbin	"bin/s13_b01.adpcm"
s13_b02:					@ 12868 bytes = 25736 samples = 2.33 s
	SAMPLE	0, 12868, 0
	.incbin	"bin/s13_b02.adpcm"
s13_b03:					@ 35825 bytes = 71650 samples = 6.50 s
	SAMPLE	0, 35825, 0
	.incbin	"bin/s13_b03.adpcm"
	.space	3
s13_b04:					@ 94154 bytes = 188308 samples = 17.08 s
	SAMPLE	0, 94154, 0
	.incbin	"bin/s13_b04.adpcm"
	.space	2
s13_b05:					@ 35279 bytes = 70558 samples = 6.40 s
	SAMPLE	0, 35279, 0
	.incbin	"bin/s13_b05.adpcm"
	.space	1
s13_b06:					@ 12912 bytes = 25824 samples = 2.34 s
	SAMPLE	0, 12912, 0
	.incbin	"bin/s13_b06.adpcm"
s03_b00:					@ 26085 bytes = 52170 samples = 4.73 s
	SAMPLE	0, 26085, 0
	.incbin	"bin/s03_b00.adpcm"
	.space	3
s03_b01:					@ 13048 bytes = 26096 samples = 2.37 s
	SAMPLE	0, 13048, 0
	.incbin	"bin/s03_b01.adpcm"
s03_b02:					@ 9864 bytes = 19728 samples = 1.79 s
	SAMPLE	0, 9864, 0
	.incbin	"bin/s03_b02.adpcm"
s03_b03:					@ 3199 bytes = 6398 samples = 0.58 s
	SAMPLE	0, 3199, 0
	.incbin	"bin/s03_b03.adpcm"
	.space	1
s03_b04:					@ 3366 bytes = 6732 samples = 0.61 s
	SAMPLE	0, 3366, 0
	.incbin	"bin/s03_b04.adpcm"
	.space	2
s03_b05:					@ 78305 bytes = 156610 samples = 14.20 s
	SAMPLE	0, 78305, 0
	.incbin	"bin/s03_b05.adpcm"
	.space	3
s03_b06:					@ 42560 bytes = 85120 samples = 7.72 s
	SAMPLE	0, 42560, 0
	.incbin	"bin/s03_b06.adpcm"
s03_b07:					@ 9656 bytes = 19312 samples = 1.75 s
	SAMPLE	0, 9656, 0
	.incbin	"bin/s03_b07.adpcm"
s03_b08:					@ 9462 bytes = 18924 samples = 1.72 s
	SAMPLE	0, 9462, 0
	.incbin	"bin/s03_b08.adpcm"
	.space	2
s03_b09:					@ 104831 bytes = 209662 samples = 19.02 s
	SAMPLE	0, 104831, 0
	.incbin	"bin/s03_b09.adpcm"
	.space	1
s03_b10:					@ 26174 bytes = 52348 samples = 4.75 s
	SAMPLE	0, 26174, 0
	.incbin	"bin/s03_b10.adpcm"
	.space	2
s03_b11:					@ 130568 bytes = 261136 samples = 23.69 s
	SAMPLE	0, 130568, 0
	.incbin	"bin/s03_b11.adpcm"
s06_b00:					@ 1544 bytes = 3088 samples = 0.28 s
	SAMPLE	0, 1544, 0
	.incbin	"bin/s06_b00.adpcm"
s06_b01:					@ 6658 bytes = 13316 samples = 1.21 s
	SAMPLE	0, 6658, 0
	.incbin	"bin/s06_b01.adpcm"
	.space	2
s06_b02:					@ 6593 bytes = 13186 samples = 1.20 s
	SAMPLE	0, 6593, 0
	.incbin	"bin/s06_b02.adpcm"
	.space	3
s06_b03:					@ 13218 bytes = 26436 samples = 2.40 s
	SAMPLE	0, 13218, 0
	.incbin	"bin/s06_b03.adpcm"
	.space	2
s06_b04:					@ 3286 bytes = 6572 samples = 0.60 s
	SAMPLE	0, 3286, 0
	.incbin	"bin/s06_b04.adpcm"
	.space	2
s06_b05:					@ 3433 bytes = 6866 samples = 0.62 s
	SAMPLE	0, 3433, 0
	.incbin	"bin/s06_b05.adpcm"
	.space	3
s06_b06:					@ 18400 bytes = 36800 samples = 3.34 s
	SAMPLE	0, 18400, 0
	.incbin	"bin/s06_b06.adpcm"
s06_b07:					@ 8244 bytes = 16488 samples = 1.50 s
	SAMPLE	0, 8244, 0
	.incbin	"bin/s06_b07.adpcm"
s06_b08:					@ 8236 bytes = 16472 samples = 1.49 s
	SAMPLE	0, 8236, 0
	.incbin	"bin/s06_b08.adpcm"
s06_b09:					@ 9967 bytes = 19934 samples = 1.81 s
	SAMPLE	0, 9967, 0
	.incbin	"bin/s06_b09.adpcm"
	.space	1
s06_b10:					@ 9984 bytes = 19968 samples = 1.81 s
	SAMPLE	0, 9984, 0
	.incbin	"bin/s06_b10.adpcm"
s06_b11:					@ 3349 bytes = 6698 samples = 0.61 s
	SAMPLE	0, 3349, 0
	.incbin	"bin/s06_b11.adpcm"
	.space	3
s01_b00:					@ 14111 bytes = 28222 samples = 2.56 s
	SAMPLE	0, 14111, 0
	.incbin	"bin/s01_b00.adpcm"
	.space	1
s01_b01:					@ 14267 bytes = 28534 samples = 2.59 s
	SAMPLE	0, 14267, 0
	.incbin	"bin/s01_b01.adpcm"
	.space	1
s01_b02:					@ 10718 bytes = 21436 samples = 1.94 s
	SAMPLE	0, 10718, 0
	.incbin	"bin/s01_b02.adpcm"
	.space	2
s01_b03:					@ 3597 bytes = 7194 samples = 0.65 s
	SAMPLE	0, 3597, 0
	.incbin	"bin/s01_b03.adpcm"
	.space	3
s01_b04:					@ 17488 bytes = 34976 samples = 3.17 s
	SAMPLE	0, 17488, 0
	.incbin	"bin/s01_b04.adpcm"
s01_b05:					@ 113256 bytes = 226512 samples = 20.55 s
	SAMPLE	0, 113256, 0
	.incbin	"bin/s01_b05.adpcm"
s01_b06:					@ 100737 bytes = 201474 samples = 18.27 s
	SAMPLE	0, 100737, 0
	.incbin	"bin/s01_b06.adpcm"
	.space	3
s01_b07:					@ 12127 bytes = 24254 samples = 2.20 s
	SAMPLE	0, 12127, 0
	.incbin	"bin/s01_b07.adpcm"
	.space	1
s01_b08:					@ 20998 bytes = 41996 samples = 3.81 s
	SAMPLE	0, 20998, 0
	.incbin	"bin/s01_b08.adpcm"
	.space	2
s01_b09:					@ 1664 bytes = 3328 samples = 0.30 s
	SAMPLE	0, 1664, 0
	.incbin	"bin/s01_b09.adpcm"
s01_b10:					@ 3639 bytes = 7278 samples = 0.66 s
	SAMPLE	0, 3639, 0
	.incbin	"bin/s01_b10.adpcm"
	.space	1
s01_b11:					@ 1793 bytes = 3586 samples = 0.33 s
	SAMPLE	0, 1793, 0
	.incbin	"bin/s01_b11.adpcm"
	.space	3
s01_b12:					@ 3491 bytes = 6982 samples = 0.63 s
	SAMPLE	0, 3491, 0
	.incbin	"bin/s01_b12.adpcm"
	.space	1
s01_b13:					@ 5411 bytes = 10822 samples = 0.98 s
	SAMPLE	0, 5411, 0
	.incbin	"bin/s01_b13.adpcm"
	.space	1
s01_b14:					@ 8831 bytes = 17662 samples = 1.60 s
	SAMPLE	0, 8831, 0
	.incbin	"bin/s01_b14.adpcm"
	.space	1
s01_b15:					@ 5276 bytes = 10552 samples = 0.96 s
	SAMPLE	0, 5276, 0
	.incbin	"bin/s01_b15.adpcm"
s01_b16:					@ 5404 bytes = 10808 samples = 0.98 s
	SAMPLE	0, 5404, 0
	.incbin	"bin/s01_b16.adpcm"
s08_b00:					@ 17966 bytes = 35932 samples = 3.26 s
	SAMPLE	0, 17966, 0
	.incbin	"bin/s08_b00.adpcm"
	.space	2
s08_b01:					@ 17958 bytes = 35916 samples = 3.26 s
	SAMPLE	0, 17958, 0
	.incbin	"bin/s08_b01.adpcm"
	.space	2
s08_b02:					@ 4637 bytes = 9274 samples = 0.84 s
	SAMPLE	0, 4637, 0
	.incbin	"bin/s08_b02.adpcm"
	.space	3
s08_b03:					@ 2979 bytes = 5958 samples = 0.54 s
	SAMPLE	0, 2979, 0
	.incbin	"bin/s08_b03.adpcm"
	.space	1
s08_b04:					@ 4416 bytes = 8832 samples = 0.80 s
	SAMPLE	0, 4416, 0
	.incbin	"bin/s08_b04.adpcm"
s08_b05:					@ 3168 bytes = 6336 samples = 0.57 s
	SAMPLE	0, 3168, 0
	.incbin	"bin/s08_b05.adpcm"
s08_b06:					@ 12064 bytes = 24128 samples = 2.19 s
	SAMPLE	0, 12064, 0
	.incbin	"bin/s08_b06.adpcm"
s08_b07:					@ 12255 bytes = 24510 samples = 2.22 s
	SAMPLE	0, 12255, 0
	.incbin	"bin/s08_b07.adpcm"
	.space	1
s08_b08:					@ 4365 bytes = 8730 samples = 0.79 s
	SAMPLE	0, 4365, 0
	.incbin	"bin/s08_b08.adpcm"
	.space	3
s08_b09:					@ 7745 bytes = 15490 samples = 1.40 s
	SAMPLE	0, 7745, 0
	.incbin	"bin/s08_b09.adpcm"
	.space	3
s08_b10:					@ 7423 bytes = 14846 samples = 1.35 s
	SAMPLE	0, 7423, 0
	.incbin	"bin/s08_b10.adpcm"
	.space	1
s07_b00:					@ 12654 bytes = 25308 samples = 2.30 s
	SAMPLE	0, 12654, 0
	.incbin	"bin/s07_b00.adpcm"
	.space	2
s07_b01:					@ 2886 bytes = 5772 samples = 0.52 s
	SAMPLE	0, 2886, 0
	.incbin	"bin/s07_b01.adpcm"
	.space	2
s07_b02:					@ 2855 bytes = 5710 samples = 0.52 s
	SAMPLE	0, 2855, 0
	.incbin	"bin/s07_b02.adpcm"
	.space	1
s07_b03:					@ 12605 bytes = 25210 samples = 2.29 s
	SAMPLE	0, 12605, 0
	.incbin	"bin/s07_b03.adpcm"
	.space	3
s07_b04:					@ 7835 bytes = 15670 samples = 1.42 s
	SAMPLE	0, 7835, 0
	.incbin	"bin/s07_b04.adpcm"
	.space	1
s07_b05:					@ 7851 bytes = 15702 samples = 1.42 s
	SAMPLE	0, 7851, 0
	.incbin	"bin/s07_b05.adpcm"
	.space	1
s07_b06:					@ 2896 bytes = 5792 samples = 0.53 s
	SAMPLE	0, 2896, 0
	.incbin	"bin/s07_b06.adpcm"
s07_b07:					@ 4744 bytes = 9488 samples = 0.86 s
	SAMPLE	0, 4744, 0
	.incbin	"bin/s07_b07.adpcm"
s07_b08:					@ 4722 bytes = 9444 samples = 0.86 s
	SAMPLE	0, 4722, 0
	.incbin	"bin/s07_b08.adpcm"
	.space	2
s10_b00:					@ 13279 bytes = 26558 samples = 2.41 s
	SAMPLE	0, 13279, 0
	.incbin	"bin/s10_b00.adpcm"
	.space	1
s10_b01:					@ 3089 bytes = 6178 samples = 0.56 s
	SAMPLE	0, 3089, 0
	.incbin	"bin/s10_b01.adpcm"
	.space	3
s10_b02:					@ 3112 bytes = 6224 samples = 0.56 s
	SAMPLE	0, 3112, 0
	.incbin	"bin/s10_b02.adpcm"
s04_b00:					@ 5712 bytes = 11424 samples = 1.04 s
	SAMPLE	0, 5712, 0
	.incbin	"bin/s04_b00.adpcm"
s04_b01:					@ 2128 bytes = 4256 samples = 0.39 s
	SAMPLE	0, 2128, 0
	.incbin	"bin/s04_b01.adpcm"
s04_b02:					@ 7520 bytes = 15040 samples = 1.36 s
	SAMPLE	0, 7520, 0
	.incbin	"bin/s04_b02.adpcm"
s04_b03:					@ 7537 bytes = 15074 samples = 1.37 s
	SAMPLE	0, 7537, 0
	.incbin	"bin/s04_b03.adpcm"
	.space	3
s04_b04:					@ 24096 bytes = 48192 samples = 4.37 s
	SAMPLE	0, 24096, 0
	.incbin	"bin/s04_b04.adpcm"
s04_b05:					@ 3456 bytes = 6912 samples = 0.63 s
	SAMPLE	0, 3456, 0
	.incbin	"bin/s04_b05.adpcm"
s04_b06:					@ 20704 bytes = 41408 samples = 3.76 s
	SAMPLE	0, 20704, 0
	.incbin	"bin/s04_b06.adpcm"
s04_b07:					@ 4361 bytes = 8722 samples = 0.79 s
	SAMPLE	0, 4361, 0
	.incbin	"bin/s04_b07.adpcm"
	.space	3
s04_b08:					@ 20480 bytes = 40960 samples = 3.72 s
	SAMPLE	0, 20480, 0
	.incbin	"bin/s04_b08.adpcm"
s04_b09:					@ 20832 bytes = 41664 samples = 3.78 s
	SAMPLE	0, 20832, 0
	.incbin	"bin/s04_b09.adpcm"
s04_b10:					@ 20798 bytes = 41596 samples = 3.77 s
	SAMPLE	0, 20798, 0
	.incbin	"bin/s04_b10.adpcm"
	.space	2
s04_b11:					@ 4487 bytes = 8974 samples = 0.81 s
	SAMPLE	0, 4487, 0
	.incbin	"bin/s04_b11.adpcm"
	.space	1
s04_b12:					@ 10240 bytes = 20480 samples = 1.86 s
	SAMPLE	0, 10240, 0
	.incbin	"bin/s04_b12.adpcm"
s04_b13:					@ 7438 bytes = 14876 samples = 1.35 s
	SAMPLE	0, 7438, 0
	.incbin	"bin/s04_b13.adpcm"
	.space	2
s04_b14:					@ 22672 bytes = 45344 samples = 4.11 s
	SAMPLE	0, 22672, 0
	.incbin	"bin/s04_b14.adpcm"
s04_b15:					@ 22208 bytes = 44416 samples = 4.03 s
	SAMPLE	0, 22208, 0
	.incbin	"bin/s04_b15.adpcm"
s04_b16:					@ 2079 bytes = 4158 samples = 0.38 s
	SAMPLE	0, 2079, 0
	.incbin	"bin/s04_b16.adpcm"
	.space	1
s05_b00:					@ 6936 bytes = 13872 samples = 1.26 s
	SAMPLE	0, 6936, 0
	.incbin	"bin/s05_b00.adpcm"
s05_b01:					@ 18911 bytes = 37822 samples = 3.43 s
	SAMPLE	0, 18911, 0
	.incbin	"bin/s05_b01.adpcm"
	.space	1
s05_b02:					@ 10519 bytes = 21038 samples = 1.91 s
	SAMPLE	0, 10519, 0
	.incbin	"bin/s05_b02.adpcm"
	.space	1
s05_b03:					@ 8329 bytes = 16658 samples = 1.51 s
	SAMPLE	0, 8329, 0
	.incbin	"bin/s05_b03.adpcm"
	.space	3
s05_b04:					@ 8265 bytes = 16530 samples = 1.50 s
	SAMPLE	0, 8265, 0
	.incbin	"bin/s05_b04.adpcm"
	.space	3
s05_b05:					@ 9600 bytes = 19200 samples = 1.74 s
	SAMPLE	0, 9600, 0
	.incbin	"bin/s05_b05.adpcm"
s05_b06:					@ 14081 bytes = 28162 samples = 2.55 s
	SAMPLE	0, 14081, 0
	.incbin	"bin/s05_b06.adpcm"
	.space	3
s05_b07:					@ 4672 bytes = 9344 samples = 0.85 s
	SAMPLE	0, 4672, 0
	.incbin	"bin/s05_b07.adpcm"
s05_b08:					@ 4717 bytes = 9434 samples = 0.86 s
	SAMPLE	0, 4717, 0
	.incbin	"bin/s05_b08.adpcm"
	.space	3
s05_b09:					@ 11936 bytes = 23872 samples = 2.17 s
	SAMPLE	0, 11936, 0
	.incbin	"bin/s05_b09.adpcm"
s05_b10:					@ 7072 bytes = 14144 samples = 1.28 s
	SAMPLE	0, 7072, 0
	.incbin	"bin/s05_b10.adpcm"
s09_b00:					@ 280 bytes = 560 samples = 0.05 s
	SAMPLE	0, 280, 0
	.incbin	"bin/s09_b00.adpcm"
s09_b01:					@ 22723 bytes = 45446 samples = 4.12 s
	SAMPLE	0, 22723, 0
	.incbin	"bin/s09_b01.adpcm"
	.space	1
s09_b02:					@ 2460 bytes = 4920 samples = 0.45 s
	SAMPLE	0, 2460, 0
	.incbin	"bin/s09_b02.adpcm"
s09_b03:					@ 2144 bytes = 4288 samples = 0.39 s
	SAMPLE	0, 2144, 0
	.incbin	"bin/s09_b03.adpcm"
s09_b04:					@ 20511 bytes = 41022 samples = 3.72 s
	SAMPLE	0, 20511, 0
	.incbin	"bin/s09_b04.adpcm"
	.space	1
s09_b05:					@ 4736 bytes = 9472 samples = 0.86 s
	SAMPLE	0, 4736, 0
	.incbin	"bin/s09_b05.adpcm"
s09_b06:					@ 4741 bytes = 9482 samples = 0.86 s
	SAMPLE	0, 4741, 0
	.incbin	"bin/s09_b06.adpcm"
	.space	3
s09_b07:					@ 12480 bytes = 24960 samples = 2.26 s
	SAMPLE	0, 12480, 0
	.incbin	"bin/s09_b07.adpcm"
s09_b08:					@ 12798 bytes = 25596 samples = 2.32 s
	SAMPLE	0, 12798, 0
	.incbin	"bin/s09_b08.adpcm"
	.space	2
s09_b09:					@ 4753 bytes = 9506 samples = 0.86 s
	SAMPLE	0, 4753, 0
	.incbin	"bin/s09_b09.adpcm"
	.space	3
s09_b10:					@ 4718 bytes = 9436 samples = 0.86 s
	SAMPLE	0, 4718, 0
	.incbin	"bin/s09_b10.adpcm"
	.space	2
s09_b11:					@ 4736 bytes = 9472 samples = 0.86 s
	SAMPLE	0, 4736, 0
	.incbin	"bin/s09_b11.adpcm"
s09_b12:					@ 3233 bytes = 6466 samples = 0.59 s
	SAMPLE	0, 3233, 0
	.incbin	"bin/s09_b12.adpcm"
	.space	3
s09_b13:					@ 3576 bytes = 7152 samples = 0.65 s
	SAMPLE	0, 3576, 0
	.incbin	"bin/s09_b13.adpcm"
s00_b00:					@ 12438 bytes = 24876 samples = 2.26 s
	SAMPLE	0, 12438, 0
	.incbin	"bin/s00_b00.adpcm"
	.space	2
s00_b01:					@ 3275 bytes = 6550 samples = 0.59 s
	SAMPLE	0, 3275, 0
	.incbin	"bin/s00_b01.adpcm"
	.space	1
s00_b02:					@ 9234 bytes = 18468 samples = 1.68 s
	SAMPLE	0, 9234, 0
	.incbin	"bin/s00_b02.adpcm"
	.space	2
s00_b03:					@ 9189 bytes = 18378 samples = 1.67 s
	SAMPLE	0, 9189, 0
	.incbin	"bin/s00_b03.adpcm"
	.space	3
s00_b04:					@ 99827 bytes = 199654 samples = 18.11 s
	SAMPLE	0, 99827, 0
	.incbin	"bin/s00_b04.adpcm"
	.space	1
s12_b00:					@ 20080 bytes = 40160 samples = 3.64 s
	SAMPLE	0, 20080, 0
	.incbin	"bin/s12_b00.adpcm"
s14_b00:					@ 27520 bytes = 55040 samples = 4.99 s
	SAMPLE	0, 27520, 0
	.incbin	"bin/s14_b00.adpcm"
s14_b01:					@ 7872 bytes = 15744 samples = 1.43 s
	SAMPLE	0, 7872, 0
	.incbin	"bin/s14_b01.adpcm"
s14_b02:					@ 13696 bytes = 27392 samples = 2.48 s
	SAMPLE	0, 13696, 0
	.incbin	"bin/s14_b02.adpcm"
s14_b03:					@ 6016 bytes = 12032 samples = 1.09 s
	SAMPLE	0, 6016, 0
	.incbin	"bin/s14_b03.adpcm"
s14_b04:					@ 27232 bytes = 54464 samples = 4.94 s
	SAMPLE	0, 27232, 0
	.incbin	"bin/s14_b04.adpcm"
s15_b00:					@ 59713 bytes = 119426 samples = 10.83 s
	SAMPLE	0, 59713, 0
	.incbin	"bin/s15_b00.adpcm"
	.space	3
s15_b01:					@ 212954 bytes = 425908 samples = 38.63 s
	SAMPLE	0, 212954, 0
	.incbin	"bin/s15_b01.adpcm"

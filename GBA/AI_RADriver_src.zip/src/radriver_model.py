#!/usr/bin/env python3
"""radriver_model.py -- a reference model of RADriver (R2, Aggressive Inline (E)).

It reproduces the driver's arithmetic and its memory layout exactly (including the
n+1 loop counts and what they overwrite), so it can be compared byte for byte with the
ROM code running in an emulator (see emucheck.py). All state lives in `mem`, at the
same addresses the game uses, so the two can be diffed directly.
"""
import struct

ROMBASE = 0x08000000
# RAM variables (see radriver.inc)
SEQ_PTR, NUMVOICES, SEQ_WAIT, SEQ_PLAYING, SEQ_TEMPO, BANK = 0x03005CB0, 0x03005CB4, 0x03005CB8, 0x03005CBC, 0x03005CC0, 0x03005CC4
BUFNEG, RING, SEQ_LOOP, VOICES, TRACKS = 0x03005CC8, 0x03005CCC, 0x03005CD0, 0x03005CD4, 0x03005CD8
CFG, BUFSIZE, ACCUM, MIXED = 0x03005CF0, 0x03005CFC, 0x03005D00, 0x03005D28
WRITEPTR, LASTCUR, PITCH, NEXTHANDLE, MASTER, UNUSED12AA = 0x03001298, 0x0300129C, 0x030012A0, 0x030012A4, 0x030012A8, 0x030012AA
NOTEFREQ, DIFF, NEXTIDX = 0x087E0894, 0x087E0BB0, 0x087E11D0


class Mem:
    """GBA address space subset: ROM, EWRAM, IWRAM, and a register file for TM1CNT_L."""
    def __init__(self, rom):
        self.rom = rom
        self.ew = bytearray(0x40000)
        self.iw = bytearray(0x8000)
        self.tm1 = 0

    def _buf(self, a):
        if 0x08000000 <= a < 0x0A000000: return self.rom, a - 0x08000000
        if 0x03000000 <= a < 0x03008000: return self.iw, a - 0x03000000
        if 0x02000000 <= a < 0x02040000: return self.ew, a - 0x02000000
        raise IndexError(hex(a))

    def r8(self, a):  b, o = self._buf(a); return b[o]
    def s8(self, a):  v = self.r8(a); return v - 256 if v & 0x80 else v
    def r16(self, a): b, o = self._buf(a); return b[o] | b[o + 1] << 8
    def s16(self, a): v = self.r16(a); return v - 0x10000 if v & 0x8000 else v
    def r32(self, a): b, o = self._buf(a); return struct.unpack_from('<I', b, o)[0]
    def w8(self, a, v):  b, o = self._buf(a); b[o] = v & 0xFF
    def w16(self, a, v): b, o = self._buf(a); struct.pack_into('<H', b, o, v & 0xFFFF)
    def w32(self, a, v): b, o = self._buf(a); struct.pack_into('<I', b, o, v & 0xFFFFFFFF)


def s32(v):
    v &= 0xFFFFFFFF
    return v - (1 << 32) if v & 0x80000000 else v


class RADriver:
    def __init__(self, mem):
        self.m = mem

    # ------------------------------------------------------------- setup
    def init(self, rate, voices, ramhandle, exhandle):
        """snd_init. The game's heap is replaced by two handles supplied by the caller
        (a handle is the address of a word holding the block address)."""
        m = self.m
        ramblock, exramblock = m.r32(ramhandle), m.r32(exhandle)
        m.w32(0x03005CDC, ramhandle); m.w32(0x03005CE0, exhandle)
        voices = min(voices, 16); rate = min(rate, 0xABEA)
        m.w32(CFG, rate); m.w32(CFG + 4, 1); m.w32(CFG + 8, 0)
        bs = (rate // 40 + 15) & 0xFFF0
        m.w16(BUFSIZE, bs); m.w16(BUFNEG, -bs)
        size = bs * 3 + voices * 40
        m.w32(RING, ramblock)
        m.w32(PITCH, exramblock); m.w32(TRACKS, exramblock + 0x200)
        m.w32(ACCUM, ramblock + bs); m.w8(NUMVOICES, voices)
        m.w32(VOICES, ramblock + bs + 2 * bs)
        for a in range(ramblock, ramblock + (size & ~3)): m.w8(a, 0)
        self.buildPitchTable(rate)
        m.w32(SEQ_PTR, 0); m.w32(SEQ_PLAYING, 0)

    def buildPitchTable(self, rate):
        m = self.m; t = m.r32(PITCH)
        for k in range(128):
            v = (((m.r32(NOTEFREQ + 4 * k) * 11025) << 12) & ((1 << 64) - 1)) // 261 // rate
            m.w32(t + 4 * k, v)
        m.w32(WRITEPTR, m.r32(RING))
        m.w32(LASTCUR, 0x10000 - m.r16(BUFSIZE))
        m.w16(UNUSED12AA, 0xFFFF); m.w16(MASTER, 256)

    def setBank(self, b): self.m.w32(BANK, b)

    # ------------------------------------------------------------- voices
    def _voices(self):
        m = self.m; base = m.r32(VOICES)
        return [base + 40 * i for i in range(m.r8(NUMVOICES))]

    def _start(self, v, s, key):
        m = self.m
        m.w8(v + 0x16, 1); m.w32(v, s); m.w16(v + 0x14, 0); m.w8(v + 0x17, 0); m.w16(v + 0x10, 256)
        m.w32(v + 4, s + 16)
        m.w32(v + 8, m.r32(m.r32(PITCH) + 4 * min(key, 127))); m.w32(v + 0xC, 0)
        m.w32(v + 0x1C, 0); m.w32(v + 0x20, 0); m.w16(v + 0x24, 0)

    def _startChain(self, v, blocks, order):
        m = self.m
        s = m.r32(blocks + 4 * m.s16(order))
        m.w8(v + 0x16, 1); m.w32(v, s); m.w16(v + 0x14, 0); m.w8(v + 0x17, 0); m.w16(v + 0x10, 256)
        m.w32(v + 4, s + 16); m.w32(v + 8, m.r32(m.r32(PITCH))); m.w32(v + 0xC, 0)
        m.w32(v + 0x1C, blocks); m.w32(v + 0x20, order); m.w16(v + 0x24, 1)

    def _alloc(self, starter, *args):
        m = self.m
        for v in self._voices():
            if m.r8(v + 0x16) == 0:
                starter(v, *args)
                h = m.r32(NEXTHANDLE); m.w32(v + 0x18, h); m.w32(NEXTHANDLE, h + 1)
                return s32(h)
        return -1

    def playSample(self, s, key): return self._alloc(self._start, s, key)
    def playStream(self, blocks, order): return self._alloc(self._startChain, blocks, order)

    def playSfx(self, i, key):
        m = self.m; b = m.r32(BANK)
        if i < m.r32(b + 4): return self.playSample(m.r32(m.r32(b + 12) + 4 * i), key)
        return m.r32(b + 4)

    def find(self, h):
        m = self.m
        for v in self._voices():
            if m.r8(v + 0x16) and s32(m.r32(v + 0x18)) == h: return v
        return 0

    def stop(self, h):
        v = self.find(h)
        if v: self.m.w8(v + 0x16, 0)

    def pause(self, h):
        v = self.find(h)
        if v: self.m.w8(v + 0x16, 2)

    def resume(self, h):
        v = self.find(h)
        if v and self.m.r8(v + 0x16) == 2: self.m.w8(v + 0x16, 1)

    def setPitch(self, h, key):
        v = self.find(h)
        if v: self.m.w32(v + 8, self.m.r32(self.m.r32(PITCH) + 4 * min(key, 127)))

    def setVolume(self, h, vol):
        v = self.find(h)
        if v: self.m.w16(v + 0x10, min(vol, 256))

    # ------------------------------------------------------------- the ARM mixer
    def mixVoice(self, v, n, master):
        m = self.m
        amp = ((m.r16(v + 0x10) * master) & 0xFFFFFFFF) >> 12
        frac = m.r32(v + 0xC); pos = m.r32(v + 4); s = m.r32(v); step = m.r32(v + 8)
        acc = m.r32(ACCUM)
        typ = m.r8(s)
        end = s + 16 + m.r32(s + 4)
        over = s32(pos + (n >> 1) - end)
        cnt = n
        if typ == 0:
            cnt = n - 2 * over if over > 0 else n
        mixed = (m.r8(MIXED) + 1) & 0xFF; m.w8(MIXED, mixed)
        first = mixed == 1
        if typ == 1 and cnt != 0:
            c = cnt
            while True:
                smp = m.s8(pos)
                frac += (step << 4) & 0xFFFFFFFF
                pos += (step >> 28) + (frac >> 32); frac &= 0xFFFFFFFF
                if first: m.w16(acc, smp * amp)
                else:     m.w16(acc, m.s16(acc) + smp * amp)
                acc += 2
                c -= 1
                if c < 0: break
        elif typ == 0 and first:
            pred = m.s16(v + 0x14); idx = m.r8(v + 0x17)
            k = (cnt >> 1) - 1
            while k != -1:
                b = m.r8(pos) ^ 0xEC; pos += 1
                for nib in (b >> 4, b & 15):
                    pred += m.s16(DIFF + 32 * idx + 2 * nib)
                    pred = 2047 if pred >= 2047 else (-2048 if pred <= -2049 else pred)
                    m.w16(acc, (pred >> 3) * amp); acc += 2
                    idx = m.r8(NEXTIDX + 8 * idx + (nib & 7))
                if over >= 0 and k == 0 and m.r32(v + 0x1C):
                    ci = m.r16(v + 0x24); m.w16(v + 0x24, ci + 1)
                    order = m.r32(v + 0x20)
                    i = m.s16(order + 2 * ci)
                    if i == -1:
                        m.w16(v + 0x24, 1); i = m.s16(order)
                    k = 0
                    if i != -1:
                        nb = m.r32(m.r32(v + 0x1C) + 4 * i)
                        k = over; pos = nb + 16; m.w32(v, nb)
                    over = -1; pred = 0; idx = 0
                k -= 1
            m.w8(v + 0x17, idx); m.w16(v + 0x14, pred)
        m.w32(v + 0xC, frac); m.w32(v + 4, pos)

    def downmix(self, dst, n, accoff):
        m = self.m
        src = m.r32(ACCUM) + 2 * accoff
        if dst == 0 or n == 0: return
        if m.r8(MIXED):
            c = n
            while True:
                x = m.s16(src) >> 4; src += 2
                m.w8(dst, max(-128, min(127, x))); dst += 1
                c -= 1
                if c < 0: break
        else:
            for i in range(n): m.w8(dst + i, 0)

    # ------------------------------------------------------------- per frame
    def voice_mix(self, v, n, master):
        m = self.m
        if m.r8(v + 0x16) != 1: return
        self.mixVoice(v, n, master)
        s = m.r32(v); end = (s + 16 + m.r32(s + 4)) & 0xFFFFFFFF; loop = m.r32(s + 8)
        pos = m.r32(v + 4)
        if pos >= end:
            if loop:
                lp = (s + 16 + loop) & 0xFFFFFFFF
                d = (end - lp) & 0xFFFFFFFF          # __umodsi3: unsigned; x % 0 returns 0
                r = (pos - end) & 0xFFFFFFFF
                m.w32(v + 4, lp + (r % d if d else 0))
            else:
                m.w8(v + 0x16, 0)

    def update(self):
        m = self.m
        if not m.r32(RING) or not m.r32(CFG + 4): return
        self.seq_tick()
        last = m.r32(LASTCUR)
        cur = (m.tm1 + 1) & ~1
        if cur == 0x10000: cur = m.r16(BUFNEG)
        m.w32(LASTCUR, cur)
        if cur > last: n1, n2 = cur - last, 0
        else: n1, n2 = 0x10000 - last, (m.r16(BUFSIZE) - 0x10000 + cur) & 0xFFFFFFFF
        m.w8(MIXED, 0)
        for v in self._voices(): self.voice_mix(v, (n1 + n2) & 0xFFFFFFFF, m.r16(MASTER))
        wp = m.r32(WRITEPTR)
        self.downmix(wp, n1, 0); wp += n1; m.w32(WRITEPTR, wp)
        if n2:
            wp -= m.r16(BUFSIZE); m.w32(WRITEPTR, wp)
            self.downmix(wp, n2, n1); m.w32(WRITEPTR, wp + n2)
        wp = m.r32(WRITEPTR)
        if wp == m.r32(RING) + m.r16(BUFSIZE): m.w32(WRITEPTR, wp - m.r16(BUFSIZE))

    # ------------------------------------------------------------- sequencer
    def playSong(self, i):
        m = self.m; b = m.r32(BANK)
        if i >= m.r32(b): return
        self.releaseAll()
        e = m.r32(b + 8) + 8 * i
        m.w32(SEQ_PTR, m.r32(e)); m.w32(SEQ_LOOP, m.r32(e + 4))
        m.w32(SEQ_WAIT, 0); m.w32(SEQ_TEMPO, 0); m.w32(SEQ_PLAYING, 1)

    def releaseAll(self):
        m = self.m
        if m.r32(SEQ_PLAYING) != 1: return
        t = m.r32(TRACKS)
        for ch in range(16):
            for j in range(4):
                sl = t + 36 * ch + 4 + 8 * j
                if m.r8(sl):
                    self.stop(s32(m.r32(sl + 4))); m.w8(sl, 0)
        m.w32(SEQ_PLAYING, 0)

    def seq_tick(self):
        m = self.m
        if m.r32(SEQ_PLAYING) != 1: return
        w = s32(m.r32(SEQ_WAIT) - m.r32(SEQ_TEMPO)); m.w32(SEQ_WAIT, w)
        if w > 0: return
        while True:
            p = m.r32(SEQ_PTR); b = m.r8(p); p += 1; m.w32(SEQ_PTR, p)
            if not b & 0x80:
                m.w32(SEQ_PTR, p + 1)
                m.w32(SEQ_WAIT, m.r32(SEQ_WAIT) + ((((b << 8) | m.r8(p)) << 16) & 0xFFFFFFFF))
            else:
                ch = b & 15; t = m.r32(TRACKS) + 36 * ch; hi = b >> 4
                if hi == 8:
                    key = m.r8(p); m.w32(SEQ_PTR, p + 2)
                    for j in range(4):
                        sl = t + 4 + 8 * j
                        if m.r8(sl) and m.r8(sl + 1) == key:
                            self.stop(s32(m.r32(sl + 4))); m.w8(sl, 0); break
                elif hi == 9:
                    key = m.r8(p); vel = m.r8(p + 1); m.w32(SEQ_PTR, p + 2)
                    prog = m.r32(t)
                    if prog and not any(m.r8(t + 4 + 8 * j) and m.r8(t + 5 + 8 * j) == key for j in range(4)):
                        for j in range(4):
                            sl = t + 4 + 8 * j
                            if not m.r8(sl):
                                h = self.playSample(prog, key); m.w32(sl + 4, h)
                                self.setVolume(h, vel); m.w8(sl, 1); m.w8(sl + 1, key)
                                break
                elif hi == 0xB:
                    if ch == 0: m.w32(SEQ_PTR, m.r32(SEQ_LOOP))
                    elif ch == 1: m.w32(SEQ_PTR, p + 1)
                    elif ch == 2:
                        m.w32(SEQ_TEMPO, struct.unpack('>I', bytes(m.r8(p + i) for i in range(4)))[0])
                        m.w32(SEQ_PTR, p + 4)
                elif hi == 0xC:
                    pp = m.r8(p); m.w32(SEQ_PTR, p + 1)
                    m.w32(t, m.r32(m.r32(m.r32(BANK) + 12) + 4 * pp))
                elif hi == 0xD:
                    m.w32(SEQ_PTR, p + 1)
            if s32(m.r32(SEQ_WAIT)) > 0: break

@ ================================================================================
@  RADriver -- Full Fat's GBA sound driver, R2 revision, as linked in
@  Aggressive Inline (E) (AILP).  Thumb part: 0x0805B284-0x0805BCD0 (2636 bytes).
@
@  Function, variable and type names are descriptive: the ROM has no symbols.
@  Only NFSU's later build gives real API names (playRADriverSound,
@  playRADriverCompressedSong).
@
@  typedef struct {             // 16-byte header, data follows
@      u8  type;                // 0 = 4-bit OKI ADPCM (bytes XOR 0xEC), 1 = s8 PCM
@      u8  pad[3];
@      u32 length;              // bytes of data
@      u32 loopStart;           // byte offset; 0 = one-shot
@      u32 zero;
@      u8  data[];
@  } Sample;
@
@  typedef struct {             // 40 bytes, snd_voices[snd_numVoices]
@      Sample *sample;          // +00
@      u8     *pos;             // +04 integer read position
@      u32     step;            // +08 4.28 resampling step (PCM only)
@      u32     frac;            // +0C fractional position
@      u16     volume;          // +10 0..256
@      u16     pad12;
@      s16     adpcmPred;       // +14 ADPCM predictor (12-bit range)
@      u8      state;           // +16 0 free, 1 playing, 2 paused
@      u8      adpcmIndex;      // +17 ADPCM step index 0..48
@      s32     handle;          // +18
@      Sample **chainBlocks;    // +1C stream: block table (0 = not a stream)
@      s16    *chainOrder;      // +20 stream: order list, -1 terminated
@      u16     chainIndex;      // +24 stream: next order-list position
@      u16     pad26;
@  } Voice;
@
@  typedef struct { u8 *start; u8 *loop; } Song;
@  typedef struct { u32 songCount, sampleCount; Song *songs; Sample **samples; } Bank;
@
@  typedef struct {             // 36 bytes, seq_tracks[16] (one per MIDI channel)
@      Sample *program;
@      struct { u8 active, key, pad[2]; s32 handle; } slot[4];
@  } Track;
@
@  Memory: snd_init allocates bufSize*3 + voices*40 bytes from the game's IWRAM
@  heap -- ring (s8[bufSize], played by DMA1), accum (s16[bufSize]) directly
@  after it, then the voices -- and 0x440 bytes of EWRAM: the 128-entry pitch
@  table followed by the 16 sequencer tracks.
@ ================================================================================
	.include "radriver.inc"
	.syntax unified
	.thumb
	.section .text.radriver,"ax",%progbits
	.balign 4

@ ==================== snd_setMasterVolume  (0805B284) ====================
@ void snd_setMasterVolume(u32 vol)        // never called by the game
@ {
@     if (vol > 256) vol = 256;
@     snd_masterVol = vol;
@ }
	.thumb_func
	.global snd_setMasterVolume
snd_setMasterVolume:
	adds	r1, r0, #0
	movs	r0, #0x80
	lsls	r0, r0, #1
	cmp	r1, r0
	bls	.L0805B290
	adds	r1, r0, #0
.L0805B290:
	ldr	r0, .Lw0805B298                    @ =snd_masterVol
	strh	r1, [r0]
	bx	lr
	.hword	0x0000				@ alignment padding
.Lw0805B298:
	.word	snd_masterVol

@ ==================== snd_getMasterVolume  (0805B29C) ====================
@ u32 snd_getMasterVolume(void)            // never called by the game
@ {
@     return snd_masterVol;
@ }
	.thumb_func
	.global snd_getMasterVolume
snd_getMasterVolume:
	ldr	r0, .Lw0805B2A4                    @ =snd_masterVol
	ldrh	r0, [r0]
	bx	lr
	.hword	0x0000				@ alignment padding
.Lw0805B2A4:
	.word	snd_masterVol

@ ==================== snd_shutdown  (0805B2A8) ====================
@ void snd_shutdown(void)
@ {
@     if (!snd_ramBlock) return;
@     REG_DMA1CNT = REG_DMA2CNT = REG_TM1CNT = REG_TM0CNT = 0;
@     mem_free(snd_ramBlock);
@     if (snd_exramBlock) mem_free(snd_exramBlock);
@     seq_tracks = 0;  snd_ramBlock = 0;  snd_ring = 0;  snd_accum = 0;   // snd_exramBlock left stale
@ }
	.thumb_func
	.global snd_shutdown
snd_shutdown:
	push	{r4, r5, lr}
	ldr	r5, .Lw0805B2EC                    @ =snd_ramBlock
	ldr	r1, [r5]
	cmp	r1, #0
	beq	.L0805B2E4
	ldr	r0, .Lw0805B2F0                    @ =REG_DMA1CNT
	movs	r4, #0
	str	r4, [r0]
	adds	r0, #0xc
	str	r4, [r0]
	adds	r0, #0x34
	str	r4, [r0]
	subs	r0, #4
	str	r4, [r0]
	adds	r0, r1, #0
	bl	mem_free
	ldr	r0, .Lw0805B2F4                    @ =snd_exramBlock
	ldr	r0, [r0]
	cmp	r0, #0
	beq	.L0805B2D6
	bl	mem_free
.L0805B2D6:
	ldr	r0, .Lw0805B2F8                    @ =seq_tracks
	str	r4, [r0]
	str	r4, [r5]
	ldr	r0, .Lw0805B2FC                    @ =snd_ring
	str	r4, [r0]
	ldr	r0, .Lw0805B300                    @ =snd_accum
	str	r4, [r0]
.L0805B2E4:
	pop	{r4, r5}
	pop	{r0}
	bx	r0
	.hword	0x0000				@ alignment padding
.Lw0805B2EC:
	.word	snd_ramBlock
.Lw0805B2F0:
	.word	REG_DMA1CNT
.Lw0805B2F4:
	.word	snd_exramBlock
.Lw0805B2F8:
	.word	seq_tracks
.Lw0805B2FC:
	.word	snd_ring
.Lw0805B300:
	.word	snd_accum

@ ==================== snd_buildPitchTable  (0805B304) ====================
@ void snd_buildPitchTable(u32 rate)
@ {
@     // step[k] = freq[k] * 11025 / 261 / rate in 4.28 fixed point, freq in 16.16 Hz:
@     // a sample recorded at 11025 Hz plays at its own pitch for key 60 (261.63 Hz).
@     // 261 is a truncated middle C, so key 60 is 0.24% (4 cents) sharp of unity.
@     for (k = 0; k < 128; k++)
@         snd_pitchTable[k] = (((u64)snd_noteFreq[k] * 11025) << 12) / 261 / rate;
@     snd_writePtr   = snd_ring;
@     snd_lastCursor = 0x10000 - snd_bufSize;   // Timer 1 count at ring start
@     snd_unused12AA = 0xFFFF;
@     snd_masterVol  = 256;
@ }
	.thumb_func
	.global snd_buildPitchTable
snd_buildPitchTable:
	push	{r4, r5, r6, r7, lr}
	mov	r7, sl
	mov	r6, sb
	mov	r5, r8
	push	{r5, r6, r7}
	mov	r8, r0
	ldr	r0, .Lw0805B394                    @ =snd_pitchTable
	ldr	r7, [r0]
	ldr	r0, .Lw0805B398                    @ =snd_noteFreq
	mov	sb, r0
	movs	r6, #0x7f
	ldr	r1, .Lw0805B39C                    @ =snd_ring
	mov	sl, r1
.L0805B31E:
	mov	r2, sb
	adds	r2, #4
	mov	sb, r2
	subs	r2, #4
	ldm	r2!, {r0}
	movs	r1, #0
	ldr	r2, .Lw0805B3A0                    @ =0x00002B11
	ldr	r3, .Lw0805B3A4                    @ =0x00000000
	bl	__muldi3                            @ freq * 11025 (64-bit)
	adds	r3, r1, #0
	adds	r2, r0, #0
	lsrs	r5, r2, #0x14
	lsls	r4, r3, #0xc
	adds	r1, r5, #0
	orrs	r1, r4
	lsls	r0, r2, #0xc                      @ << 12
	ldr	r2, .Lw0805B3A8                    @ =0x00000105
	ldr	r3, .Lw0805B3AC                    @ =0x00000000
	bl	__udivdi3                           @ / 261
	mov	r2, r8
	movs	r3, #0
	bl	__udivdi3                           @ / rate
	stm	r7!, {r0}
	subs	r6, #1
	movs	r0, #1
	rsbs	r0, r0, #0
	cmp	r6, r0
	bne	.L0805B31E
	mov	r1, sl
	ldr	r0, [r1]
	ldr	r2, .Lw0805B3B0                    @ =snd_writePtr
	str	r0, [r2]
	movs	r0, #0x80
	lsls	r0, r0, #9
	ldr	r1, .Lw0805B3B4                    @ =snd_bufSize
	ldrh	r1, [r1]
	subs	r0, r0, r1
	ldr	r2, .Lw0805B3B8                    @ =snd_lastCursor
	str	r0, [r2]
	ldr	r1, .Lw0805B3BC                    @ =0x0000FFFF
	adds	r0, r1, #0
	ldr	r2, .Lw0805B3C0                    @ =snd_unused12AA
	strh	r0, [r2]
	movs	r1, #0x80
	lsls	r1, r1, #1
	adds	r0, r1, #0
	ldr	r2, .Lw0805B3C4                    @ =snd_masterVol
	strh	r0, [r2]
	pop	{r3, r4, r5}
	mov	r8, r3
	mov	sb, r4
	mov	sl, r5
	pop	{r4, r5, r6, r7}
	pop	{r0}
	bx	r0
	.hword	0x0000				@ alignment padding
.Lw0805B394:
	.word	snd_pitchTable
.Lw0805B398:
	.word	snd_noteFreq
.Lw0805B39C:
	.word	snd_ring
.Lw0805B3A0:
	.word	0x00002B11
.Lw0805B3A4:
	.word	0x00000000
.Lw0805B3A8:
	.word	0x00000105
.Lw0805B3AC:
	.word	0x00000000
.Lw0805B3B0:
	.word	snd_writePtr
.Lw0805B3B4:
	.word	snd_bufSize
.Lw0805B3B8:
	.word	snd_lastCursor
.Lw0805B3BC:
	.word	0x0000FFFF
.Lw0805B3C0:
	.word	snd_unused12AA
.Lw0805B3C4:
	.word	snd_masterVol

@ ==================== snd_init  (0805B3C8) ====================
@ void snd_init(u32 rate, u32 voices)      // game: snd_init(11025, 2)
@ {
@     snd_shutdown();
@     if (voices > 16) voices = 16;
@     if (rate > 44010) rate = 44010;
@     snd_cfg.rate = rate;  snd_cfg.running = 1;  snd_cfg.unused = 0;
@     snd_bufSize    = (rate / 40 + 15) & ~15;     // 1/40 s, multiple of 16: 288 at 11025 Hz
@     snd_bufSizeNeg = -snd_bufSize;
@     size = snd_bufSize * 3 + voices * 40;
@     if (!(snd_ramBlock = iwram_alloc(size)))   dbg_printf(str_noRamMixer, size);
@     snd_ring = *snd_ramBlock;
@     if (!(snd_exramBlock = exram_alloc(0x440))) dbg_printf(str_noExram, 0x440);
@     snd_pitchTable = *snd_exramBlock;  seq_tracks = snd_pitchTable + 128;
@     snd_accum  = snd_ring + snd_bufSize;
@     snd_numVoices = voices;
@     snd_voices = snd_accum + snd_bufSize;        // s16 units, i.e. ring + 3*bufSize bytes
@     DMA3 fill 0 over the whole IWRAM block (size/4 words);
@     snd_buildPitchTable(rate);
@     REG_SOUNDCNT_X = 0x0080;                     // master enable
@     REG_SOUNDCNT_H = 0x0B04;                     // DSA 100%, L+R, Timer 0, FIFO A reset
@     REG_DMA1SAD = snd_ring;  REG_DMA1DAD = REG_FIFO_A;
@     REG_DMA1CNT = 0xB6000000;                    // enable, FIFO timing, 32-bit, repeat
@     REG_TM1CNT  = 0x00C40000 | (u16)(snd_bufSizeNeg - 2);   // cascade + IRQ: play cursor
@     REG_TM0CNT  = 0x00800000 | (0x10000 - 16780000 / rate); // sample clock
@     seq_ptr = 0;  seq_playing = 0;
@     // the allocation failures are only reported; the code carries on with a NULL block
@ }
	.thumb_func
	.global snd_init
snd_init:
	push	{r4, r5, r6, r7, lr}
	mov	r7, sl
	mov	r6, sb
	mov	r5, r8
	push	{r5, r6, r7}
	sub	sp, #4
	mov	r8, r0
	adds	r4, r1, #0
	bl	snd_shutdown
	cmp	r4, #0x10
	bls	.L0805B3E2
	movs	r4, #0x10
.L0805B3E2:
	ldr	r0, .Lw0805B518                    @ =0x0000ABEA
	cmp	r8, r0
	bls	.L0805B3EA
	mov	r8, r0
.L0805B3EA:
	ldr	r1, .Lw0805B51C                    @ =snd_cfg
	mov	r0, r8
	str	r0, [r1]
	movs	r0, #1
	str	r0, [r1, #4]
	movs	r2, #0
	str	r2, [r1, #8]
	ldr	r6, .Lw0805B520                    @ =snd_bufSize
	mov	sb, r6
	mov	r0, r8
	movs	r1, #0x28                         @ rate / 40
	bl	__udivsi3
	adds	r0, #0xf
	ldr	r2, .Lw0805B524                    @ =0x0000FFF0
	adds	r1, r2, #0
	ands	r0, r1                            @ & 0xFFF0 -> bufSize
	strh	r0, [r6]
	rsbs	r0, r0, #0
	ldr	r6, .Lw0805B528                    @ =snd_bufSizeNeg
	strh	r0, [r6]
	mov	r0, sb
	ldrh	r0, [r0]
	lsls	r1, r0, #1
	mov	r2, sb
	ldrh	r2, [r2]
	adds	r1, r1, r2
	lsls	r0, r4, #2
	adds	r0, r0, r4
	lsls	r0, r0, #3
	adds	r5, r1, r0                        @ r5 = bufSize*3 + voices*40
	adds	r0, r5, #0
	bl	iwram_alloc
	ldr	r6, .Lw0805B52C                    @ =snd_ramBlock
	str	r0, [r6]
	cmp	r0, #0
	bne	.L0805B43E
	ldr	r0, .Lw0805B530                    @ =str_noRamMixer
	adds	r1, r5, #0
	bl	dbg_printf
.L0805B43E:
	ldr	r0, .Lw0805B534                    @ =snd_ring
	mov	sl, r0
	ldr	r0, [r6]
	ldr	r0, [r0]
	mov	r1, sl
	str	r0, [r1]
	movs	r6, #0x88
	lsls	r6, r6, #3                        @ 0x440 = pitch table (0x200) + 16 tracks (0x240)
	adds	r0, r6, #0
	bl	exram_alloc
	ldr	r7, .Lw0805B538                    @ =snd_exramBlock
	str	r0, [r7]
	cmp	r0, #0
	bne	.L0805B464
	ldr	r0, .Lw0805B53C                    @ =str_noExram
	adds	r1, r6, #0
	bl	dbg_printf
.L0805B464:
	ldr	r1, .Lw0805B540                    @ =snd_pitchTable
	ldr	r0, [r7]
	ldr	r0, [r0]
	str	r0, [r1]
	ldr	r1, .Lw0805B544                    @ =seq_tracks
	movs	r2, #0x80
	lsls	r2, r2, #2
	adds	r0, r0, r2                        @ tracks follow the 128-entry pitch table
	str	r0, [r1]
	ldr	r0, .Lw0805B548                    @ =snd_accum
	mov	r6, sl
	ldr	r3, [r6]
	mov	r2, sb
	ldrh	r2, [r2]
	adds	r1, r2, r3
	str	r1, [r0]
	ldr	r0, .Lw0805B54C                    @ =snd_numVoices
	strb	r4, [r0]
	ldr	r2, .Lw0805B550                    @ =snd_voices
	mov	r4, sb
	ldrh	r4, [r4]
	lsls	r0, r4, #1
	adds	r1, r1, r0
	str	r1, [r2]
	movs	r6, #0
	str	r6, [sp]
	ldr	r2, .Lw0805B554                    @ =REG_DMA3SAD
	mov	r0, sp
	str	r0, [r2]
	str	r3, [r2, #4]
	lsrs	r0, r5, #2
	movs	r1, #0x85
	lsls	r1, r1, #0x18
	orrs	r0, r1
	str	r0, [r2, #8]                       @ DMA3: 32-bit fill from a zero on the stack
	ldr	r0, [r2, #8]
	mov	r0, r8
	bl	snd_buildPitchTable
	ldr	r1, .Lw0805B558                    @ =REG_SOUNDCNT_X
	movs	r0, #0x80
	strh	r0, [r1]                          @ SOUNDCNT_X = 0x80
	subs	r1, #2
	ldr	r2, .Lw0805B55C                    @ =0x00000B04
	adds	r0, r2, #0
	strh	r0, [r1]                          @ SOUNDCNT_H = 0x0B04
	adds	r1, #0x3a
	mov	r4, sl
	ldr	r0, [r4]
	str	r0, [r1]                           @ DMA1SAD = ring
	adds	r1, #4
	ldr	r0, .Lw0805B560                    @ =REG_FIFO_A
	str	r0, [r1]                           @ DMA1DAD = FIFO_A
	adds	r1, #4
	movs	r0, #0xb6
	lsls	r0, r0, #0x18
	str	r0, [r1]                           @ DMA1CNT = 0xB6000000
	ldr	r2, .Lw0805B564                    @ =REG_TM1CNT
	ldr	r6, .Lw0805B528                    @ =snd_bufSizeNeg
	ldrh	r0, [r6]
	subs	r0, #2                            @ first period is bufSize+2 samples
	movs	r1, #0xc4
	lsls	r1, r1, #0x10
	orrs	r0, r1
	str	r0, [r2]
	ldr	r4, .Lw0805B568                    @ =REG_TM0CNT
	ldr	r0, .Lw0805B56C                    @ =0x01000AE0
	mov	r1, r8
	bl	__udivsi3                           @ 16780000 / rate (the CPU clock, rounded)
	movs	r1, #0x80
	lsls	r1, r1, #9
	subs	r1, r1, r0
	movs	r0, #0x80
	lsls	r0, r0, #0x10
	orrs	r1, r0
	str	r1, [r4]                           @ TM0CNT = enable | reload
	ldr	r0, .Lw0805B570                    @ =seq_ptr
	movs	r1, #0
	str	r1, [r0]
	ldr	r0, .Lw0805B574                    @ =seq_playing
	str	r1, [r0]
	add	sp, #4
	pop	{r3, r4, r5}
	mov	r8, r3
	mov	sb, r4
	mov	sl, r5
	pop	{r4, r5, r6, r7}
	pop	{r0}
	bx	r0
.Lw0805B518:
	.word	0x0000ABEA
.Lw0805B51C:
	.word	snd_cfg
.Lw0805B520:
	.word	snd_bufSize
.Lw0805B524:
	.word	0x0000FFF0
.Lw0805B528:
	.word	snd_bufSizeNeg
.Lw0805B52C:
	.word	snd_ramBlock
.Lw0805B530:
	.word	str_noRamMixer
.Lw0805B534:
	.word	snd_ring
.Lw0805B538:
	.word	snd_exramBlock
.Lw0805B53C:
	.word	str_noExram
.Lw0805B540:
	.word	snd_pitchTable
.Lw0805B544:
	.word	seq_tracks
.Lw0805B548:
	.word	snd_accum
.Lw0805B54C:
	.word	snd_numVoices
.Lw0805B550:
	.word	snd_voices
.Lw0805B554:
	.word	REG_DMA3SAD
.Lw0805B558:
	.word	REG_SOUNDCNT_X
.Lw0805B55C:
	.word	0x00000B04
.Lw0805B560:
	.word	REG_FIFO_A
.Lw0805B564:
	.word	REG_TM1CNT
.Lw0805B568:
	.word	REG_TM0CNT
.Lw0805B56C:
	.word	0x01000AE0
.Lw0805B570:
	.word	seq_ptr
.Lw0805B574:
	.word	seq_playing

@ ==================== snd_halt  (0805B578) ====================
@ void snd_halt(void)                      // never called by the game
@ {
@     snd_cfg.running = 0;
@     REG_DMA1CNT = REG_DMA2CNT = REG_TM1CNT = REG_TM0CNT = 0;
@ }
	.thumb_func
	.global snd_halt
snd_halt:
	ldr	r0, .Lw0805B590                    @ =snd_cfg
	movs	r1, #0
	str	r1, [r0, #4]
	ldr	r0, .Lw0805B594                    @ =REG_DMA1CNT
	str	r1, [r0]
	adds	r0, #0xc
	str	r1, [r0]
	adds	r0, #0x34
	str	r1, [r0]
	subs	r0, #4
	str	r1, [r0]
	bx	lr
.Lw0805B590:
	.word	snd_cfg
.Lw0805B594:
	.word	REG_DMA1CNT

@ ==================== snd_restart  (0805B598) ====================
@ void snd_restart(void)                   // never called by the game
@ {
@     REG_DMA1CNT = 0xB6000000;
@     REG_TM1CNT  = 0x00C40000 | (u16)(snd_bufSizeNeg - 2);
@     REG_TM0CNT  = 0x00800000 | (0x10000 - 16780000 / snd_cfg.rate);
@     snd_cfg.running = 1;
@ }
	.thumb_func
	.global snd_restart
snd_restart:
	push	{r4, r5, lr}
	ldr	r1, .Lw0805B5D8                    @ =REG_DMA1CNT
	movs	r0, #0xb6
	lsls	r0, r0, #0x18
	str	r0, [r1]
	ldr	r2, .Lw0805B5DC                    @ =REG_TM1CNT
	ldr	r0, .Lw0805B5E0                    @ =snd_bufSizeNeg
	ldrh	r0, [r0]
	subs	r0, #2
	movs	r1, #0xc4
	lsls	r1, r1, #0x10
	orrs	r0, r1
	str	r0, [r2]
	ldr	r5, .Lw0805B5E4                    @ =REG_TM0CNT
	ldr	r4, .Lw0805B5E8                    @ =snd_cfg
	ldr	r1, [r4]
	ldr	r0, .Lw0805B5EC                    @ =0x01000AE0
	bl	__udivsi3
	movs	r1, #0x80
	lsls	r1, r1, #9
	subs	r1, r1, r0
	movs	r0, #0x80
	lsls	r0, r0, #0x10
	orrs	r1, r0
	str	r1, [r5]
	movs	r0, #1
	str	r0, [r4, #4]
	pop	{r4, r5}
	pop	{r0}
	bx	r0
	.hword	0x0000				@ alignment padding
.Lw0805B5D8:
	.word	REG_DMA1CNT
.Lw0805B5DC:
	.word	REG_TM1CNT
.Lw0805B5E0:
	.word	snd_bufSizeNeg
.Lw0805B5E4:
	.word	REG_TM0CNT
.Lw0805B5E8:
	.word	snd_cfg
.Lw0805B5EC:
	.word	0x01000AE0

@ ==================== snd_timer1IRQ  (0805B5F0) ====================
@ void snd_timer1IRQ(void)                 // Timer 1 overflow = DMA1 has played the whole ring
@ {
@     REG_DMA1CNT = 0;  REG_DMA2CNT = 0;  REG_TM1CNT = 0;
@     REG_TM1CNT  = 0x00C40000 | snd_bufSizeNeg;   // full ring length (no -2 this time)
@     REG_DMA1CNT = 0xB6000000;            // re-latches DMA1SAD = ring start
@ }
	.thumb_func
	.global snd_timer1IRQ
snd_timer1IRQ:
	ldr	r3, .Lw0805B614                    @ =REG_DMA1CNT
	movs	r1, #0
	str	r1, [r3]
	ldr	r0, .Lw0805B618                    @ =REG_DMA2CNT
	str	r1, [r0]
	ldr	r2, .Lw0805B61C                    @ =REG_TM1CNT
	str	r1, [r2]
	ldr	r1, .Lw0805B620                    @ =snd_bufSizeNeg
	movs	r0, #0xc4
	lsls	r0, r0, #0x10
	ldrh	r1, [r1]
	orrs	r0, r1
	str	r0, [r2]
	movs	r0, #0xb6
	lsls	r0, r0, #0x18
	str	r0, [r3]
	bx	lr
	.hword	0x0000				@ alignment padding
.Lw0805B614:
	.word	REG_DMA1CNT
.Lw0805B618:
	.word	REG_DMA2CNT
.Lw0805B61C:
	.word	REG_TM1CNT
.Lw0805B620:
	.word	snd_bufSizeNeg

@ ==================== voice_mix  (0805B624) ====================
@ void voice_mix(Voice *v, int n, int master)
@ {
@     if (v->state != 1) return;
@     (*pfn_snd_mixVoice)(v, n, master);           // ARM, in IWRAM
@     end = v->sample->data + v->sample->length;
@     if (v->pos >= end) {
@         if (v->sample->loopStart) {
@             loop = v->sample->data + v->sample->loopStart;
@             v->pos = loop + (v->pos - end) % (end - loop);
@         } else
@             v->state = 0;                        // one-shot finished: voice freed
@     }
@ }
	.thumb_func
	.global voice_mix
voice_mix:
	push	{r4, r5, lr}
	adds	r4, r0, #0
	ldrb	r0, [r4, #0x16]
	cmp	r0, #1
	bne	.L0805B666
	ldr	r0, .Lw0805B660                    @ =pfn_snd_mixVoice
	ldr	r3, [r0]
	adds	r0, r4, #0
	bl	_call_via_r3                        @ mixVoice_arm(v, n, master) through the IWRAM pointer
	ldr	r1, [r4]
	ldr	r0, [r1, #4]
	adds	r0, #0x10
	adds	r3, r1, r0
	ldr	r2, [r1, #8]
	adds	r0, r2, #0
	adds	r0, #0x10
	adds	r5, r1, r0
	ldr	r0, [r4, #4]
	cmp	r0, r3
	blo	.L0805B666
	cmp	r2, #0                             @ loopStart == 0 -> one-shot
	beq	.L0805B664
	subs	r0, r0, r3
	subs	r1, r3, r5
	bl	__umodsi3                           @ (pos - end) % (end - loop)
	adds	r0, r5, r0
	str	r0, [r4, #4]
	b	.L0805B666
.Lw0805B660:
	.word	pfn_snd_mixVoice
.L0805B664:
	strb	r2, [r4, #0x16]                   @ state = 0 (r2 is 0 here)
.L0805B666:
	pop	{r4, r5}
	pop	{r0}
	bx	r0

@ ==================== snd_update  (0805B66C) ====================
@ void snd_update(void)                    // the game calls this once per frame
@ {
@     if (!snd_ring || !snd_cfg.running) return;
@     seq_tick();
@     cur = (REG_TM1CNT_L + 1) & ~1;               // samples played so far, rounded up to even
@     if (cur == 0x10000) cur = (u16)snd_bufSizeNeg;
@     last = snd_lastCursor;  snd_lastCursor = cur;
@     if (cur > last) { n1 = cur - last;    n2 = 0; }
@     else            { n1 = 0x10000 - last; n2 = cur - (0x10000 - snd_bufSize); }   // ring wrapped
@     snd_voicesMixed = 0;
@     for (i = 0; i < snd_numVoices; i++)
@         voice_mix(&snd_voices[i], n1 + n2, snd_masterVol);
@     (*pfn_snd_downmix)(snd_writePtr, n1, 0);
@     snd_writePtr += n1;
@     if (n2) {
@         snd_writePtr -= snd_bufSize;             // back to the ring start
@         (*pfn_snd_downmix)(snd_writePtr, n2, n1);
@         snd_writePtr += n2;
@     }
@     if (snd_writePtr == snd_ring + snd_bufSize) snd_writePtr -= snd_bufSize;
@ }
@ // The CPU fills exactly the part of the ring that DMA1 played since the last call,
@ // so output latency is one ring length (288 samples = 26 ms at 11025 Hz).
	.thumb_func
	.global snd_update
snd_update:
	push	{r4, r5, r6, r7, lr}
	mov	r7, sl
	mov	r6, sb
	mov	r5, r8
	push	{r5, r6, r7}
	ldr	r0, .Lw0805B6C0                    @ =snd_voices
	ldr	r6, [r0]
	ldr	r0, .Lw0805B6C4                    @ =snd_numVoices
	ldrb	r4, [r0]
	ldr	r0, .Lw0805B6C8                    @ =snd_ring
	ldr	r0, [r0]
	cmp	r0, #0
	beq	.L0805B760
	ldr	r5, .Lw0805B6CC                    @ =snd_cfg
	ldr	r0, [r5, #4]
	cmp	r0, #0
	beq	.L0805B760
	bl	seq_tick                            @ sequencer first
	ldr	r7, .Lw0805B6D0                    @ =snd_lastCursor
	ldr	r2, [r7]
	ldr	r0, [r5, #8]                       @ dead: snd_cfg.unused is loaded and discarded
	adds	r0, #1
	movs	r5, #2
	rsbs	r5, r5, #0
	ands	r0, r5
	movs	r3, #0x80
	lsls	r3, r3, #9
	ldr	r0, .Lw0805B6D4                    @ =REG_TM1CNT
	ldrh	r0, [r0]
	adds	r1, r0, #1                        @ cursor = (TM1CNT_L + 1) & ~1
	ands	r1, r5
	cmp	r1, r3
	bne	.L0805B6B4
	ldr	r0, .Lw0805B6D8                    @ =snd_bufSizeNeg
	ldrh	r1, [r0]                          @ a full count means ring start
.L0805B6B4:
	str	r1, [r7]
	cmp	r1, r2
	bls	.L0805B6DC
	subs	r5, r1, r2                        @ no wrap: n1 = cur - last, n2 = 0
	movs	r0, #0
	b	.L0805B6E8
.Lw0805B6C0:
	.word	snd_voices
.Lw0805B6C4:
	.word	snd_numVoices
.Lw0805B6C8:
	.word	snd_ring
.Lw0805B6CC:
	.word	snd_cfg
.Lw0805B6D0:
	.word	snd_lastCursor
.Lw0805B6D4:
	.word	REG_TM1CNT
.Lw0805B6D8:
	.word	snd_bufSizeNeg
.L0805B6DC:
	subs	r5, r3, r2                        @ wrap: n1 = 0x10000 - last
	ldr	r0, .Lw0805B770                    @ =snd_bufSize
	ldrh	r0, [r0]
	ldr	r2, .Lw0805B774                    @ =0xFFFF0000
	adds	r0, r0, r2
	adds	r0, r0, r1                        @ n2 = cur - (0x10000 - bufSize)
.L0805B6E8:
	mov	sl, r0
	mov	r0, sl
	adds	r7, r5, r0
	ldr	r1, .Lw0805B778                    @ =snd_voicesMixed
	movs	r0, #0
	strb	r0, [r1]                          @ snd_voicesMixed = 0
	subs	r4, #1
	movs	r0, #1
	rsbs	r0, r0, #0
	cmp	r4, r0
	beq	.L0805B718
	ldr	r1, .Lw0805B77C                    @ =snd_masterVol
	mov	sb, r1
	mov	r8, r0
.L0805B704:
	mov	r0, sb
	ldrh	r2, [r0]
	adds	r0, r6, #0
	adds	r1, r7, #0
	bl	voice_mix                           @ mix n1+n2 samples of every voice
	adds	r6, #0x28
	subs	r4, #1
	cmp	r4, r8
	bne	.L0805B704
.L0805B718:
	ldr	r6, .Lw0805B780                    @ =pfn_snd_downmix
	ldr	r4, .Lw0805B784                    @ =snd_writePtr
	ldr	r0, [r4]
	ldr	r3, [r6]
	adds	r1, r5, #0
	movs	r2, #0
	bl	_call_via_r3                        @ downmix(writePtr, n1, 0)
	ldr	r0, [r4]
	adds	r1, r0, r5
	str	r1, [r4]
	mov	r2, sl
	cmp	r2, #0
	beq	.L0805B74C
	ldr	r0, .Lw0805B770                    @ =snd_bufSize
	ldrh	r0, [r0]
	subs	r0, r1, r0
	str	r0, [r4]
	ldr	r3, [r6]
	mov	r1, sl
	adds	r2, r5, #0
	bl	_call_via_r3                        @ downmix(ring, n2, n1)
	ldr	r0, [r4]
	add	r0, sl
	str	r0, [r4]
.L0805B74C:
	ldr	r1, .Lw0805B788                    @ =snd_ring
	ldr	r0, .Lw0805B770                    @ =snd_bufSize
	ldrh	r2, [r0]
	ldr	r0, [r1]
	adds	r0, r0, r2
	ldr	r1, [r4]
	cmp	r1, r0
	bne	.L0805B760
	subs	r0, r1, r2
	str	r0, [r4]
.L0805B760:
	pop	{r3, r4, r5}
	mov	r8, r3
	mov	sb, r4
	mov	sl, r5
	pop	{r4, r5, r6, r7}
	pop	{r0}
	bx	r0
	.hword	0x0000				@ alignment padding
.Lw0805B770:
	.word	snd_bufSize
.Lw0805B774:
	.word	0xFFFF0000
.Lw0805B778:
	.word	snd_voicesMixed
.Lw0805B77C:
	.word	snd_masterVol
.Lw0805B780:
	.word	pfn_snd_downmix
.Lw0805B784:
	.word	snd_writePtr
.Lw0805B788:
	.word	snd_ring

@ ==================== voice_start  (0805B78C) ====================
@ static void voice_start(Voice *v, Sample *s, u32 key)
@ {
@     v->state = 1;  v->sample = s;  v->adpcmPred = 0;  v->adpcmIndex = 0;
@     v->volume = 256;  v->pos = s->data;
@     if (key > 127) key = 127;
@     v->step = snd_pitchTable[key];  v->frac = 0;
@     v->chainBlocks = 0;  v->chainOrder = 0;  v->chainIndex = 0;
@ }
	.thumb_func
	.global voice_start
voice_start:
	push	{r4, lr}
	adds	r3, r0, #0
	movs	r4, #0
	movs	r0, #1
	strb	r0, [r3, #0x16]
	str	r1, [r3]
	movs	r0, #0
	strh	r4, [r3, #0x14]
	strb	r0, [r3, #0x17]
	movs	r0, #0x80
	lsls	r0, r0, #1
	strh	r0, [r3, #0x10]                   @ volume = 256
	adds	r1, #0x10
	str	r1, [r3, #4]
	cmp	r2, #0x7f                          @ key clamp 127
	bls	.L0805B7AE
	movs	r2, #0x7f
.L0805B7AE:
	ldr	r0, .Lw0805B7C8                    @ =snd_pitchTable
	ldr	r1, [r0]
	lsls	r0, r2, #2
	adds	r0, r0, r1
	ldr	r0, [r0]
	str	r0, [r3, #8]                       @ step = snd_pitchTable[key]
	str	r4, [r3, #0xc]
	str	r4, [r3, #0x1c]
	str	r4, [r3, #0x20]
	strh	r4, [r3, #0x24]
	pop	{r4}
	pop	{r0}
	bx	r0
.Lw0805B7C8:
	.word	snd_pitchTable

@ ==================== voice_startChain  (0805B7CC) ====================
@ static void voice_startChain(Voice *v, Sample **blocks, s16 *order)
@ {
@     Sample *s = blocks[order[0]];
@     v->state = 1;  v->sample = s;  v->adpcmPred = 0;  v->adpcmIndex = 0;
@     v->volume = 256;  v->pos = s->data;
@     v->step = snd_pitchTable[0];  v->frac = 0;   // step is irrelevant: ADPCM is never resampled
@     v->chainBlocks = blocks;  v->chainOrder = order;  v->chainIndex = 1;
@ }
	.thumb_func
	.global voice_startChain
voice_startChain:
	push	{r4, r5, r6, lr}
	movs	r4, #0
	ldrsh	r3, [r2, r4]
	lsls	r3, r3, #2
	adds	r3, r3, r1
	ldr	r4, [r3]
	movs	r5, #0
	movs	r6, #1
	strb	r6, [r0, #0x16]
	str	r4, [r0]
	movs	r3, #0
	strh	r5, [r0, #0x14]
	strb	r3, [r0, #0x17]
	movs	r3, #0x80
	lsls	r3, r3, #1
	strh	r3, [r0, #0x10]
	adds	r4, #0x10
	str	r4, [r0, #4]
	ldr	r3, .Lw0805B808                    @ =snd_pitchTable
	ldr	r3, [r3]
	ldr	r3, [r3]
	str	r3, [r0, #8]                       @ step = snd_pitchTable[0] (unused for ADPCM)
	str	r5, [r0, #0xc]
	str	r1, [r0, #0x1c]
	str	r2, [r0, #0x20]
	strh	r6, [r0, #0x24]                   @ chainIndex = 1
	pop	{r4, r5, r6}
	pop	{r0}
	bx	r0
	.hword	0x0000				@ alignment padding
.Lw0805B808:
	.word	snd_pitchTable

@ ==================== snd_playStream  (0805B80C) ====================
@ int snd_playStream(Sample **blocks, s16 *order)   // game: playMusic(n) -> streamTable[n]
@ {
@     for (i = 0, v = snd_voices; i < snd_numVoices; i++, v++)
@         if (v->state == 0) {
@             voice_startChain(v, blocks, order);
@             return v->handle = snd_nextHandle++;
@         }
@     dbg_printf(str_outOfChannels);
@     return -1;
@ }
	.thumb_func
	.global snd_playStream
snd_playStream:
	push	{r4, r5, lr}
	adds	r3, r0, #0
	adds	r2, r1, #0
	ldr	r0, .Lw0805B840                    @ =snd_voices
	ldr	r4, [r0]
	ldr	r0, .Lw0805B844                    @ =snd_numVoices
	ldrb	r1, [r0]
	subs	r1, #1
	movs	r0, #1
	rsbs	r0, r0, #0
	cmp	r1, r0
	beq	.L0805B858
	ldr	r5, .Lw0805B848                    @ =snd_nextHandle
.L0805B826:
	ldrb	r0, [r4, #0x16]
	cmp	r0, #0
	bne	.L0805B84C
	adds	r0, r4, #0
	adds	r1, r3, #0
	bl	voice_startChain
	ldr	r0, [r5]
	str	r0, [r4, #0x18]
	adds	r0, #1
	str	r0, [r5]
	ldr	r0, [r4, #0x18]
	b	.L0805B862
.Lw0805B840:
	.word	snd_voices
.Lw0805B844:
	.word	snd_numVoices
.Lw0805B848:
	.word	snd_nextHandle
.L0805B84C:
	adds	r4, #0x28
	subs	r1, #1
	movs	r0, #1
	rsbs	r0, r0, #0
	cmp	r1, r0
	bne	.L0805B826
.L0805B858:
	ldr	r0, .Lw0805B868                    @ =str_outOfChannels
	bl	dbg_printf
	movs	r0, #1
	rsbs	r0, r0, #0
.L0805B862:
	pop	{r4, r5}
	pop	{r1}
	bx	r1
.Lw0805B868:
	.word	str_outOfChannels

@ ==================== snd_playSample  (0805B86C) ====================
@ int snd_playSample(Sample *s, u32 key)   // first free voice, never steals
@ {
@     for (i = 0, v = snd_voices; i < snd_numVoices; i++, v++)
@         if (v->state == 0) {
@             voice_start(v, s, key);
@             return v->handle = snd_nextHandle++;
@         }
@     dbg_printf(str_outOfChannels);
@     return -1;
@ }
	.thumb_func
	.global snd_playSample
snd_playSample:
	push	{r4, r5, lr}
	adds	r3, r0, #0
	adds	r2, r1, #0
	ldr	r0, .Lw0805B8A0                    @ =snd_voices
	ldr	r4, [r0]
	ldr	r0, .Lw0805B8A4                    @ =snd_numVoices
	ldrb	r1, [r0]
	subs	r1, #1
	movs	r0, #1
	rsbs	r0, r0, #0
	cmp	r1, r0
	beq	.L0805B8B8
	ldr	r5, .Lw0805B8A8                    @ =snd_nextHandle
.L0805B886:
	ldrb	r0, [r4, #0x16]
	cmp	r0, #0
	bne	.L0805B8AC
	adds	r0, r4, #0
	adds	r1, r3, #0
	bl	voice_start
	ldr	r0, [r5]
	str	r0, [r4, #0x18]
	adds	r0, #1
	str	r0, [r5]
	ldr	r0, [r4, #0x18]
	b	.L0805B8C2
.Lw0805B8A0:
	.word	snd_voices
.Lw0805B8A4:
	.word	snd_numVoices
.Lw0805B8A8:
	.word	snd_nextHandle
.L0805B8AC:
	adds	r4, #0x28
	subs	r1, #1
	movs	r0, #1
	rsbs	r0, r0, #0
	cmp	r1, r0
	bne	.L0805B886
.L0805B8B8:
	ldr	r0, .Lw0805B8C8                    @ =str_outOfChannels
	bl	dbg_printf
	movs	r0, #1
	rsbs	r0, r0, #0
.L0805B8C2:
	pop	{r4, r5}
	pop	{r1}
	bx	r1
.Lw0805B8C8:
	.word	str_outOfChannels

@ ==================== voice_find  (0805B8CC) ====================
@ static Voice *voice_find(s32 handle)
@ {
@     for (i = 0, v = snd_voices; i < snd_numVoices; i++, v++)
@         if (v->state != 0 && v->handle == handle) return v;
@     return 0;
@ }
	.thumb_func
	.global voice_find
voice_find:
	push	{r4, lr}
	adds	r3, r0, #0
	ldr	r0, .Lw0805B8F4                    @ =snd_voices
	ldr	r1, [r0]
	ldr	r0, .Lw0805B8F8                    @ =snd_numVoices
	ldrb	r2, [r0]
	subs	r2, #1
	movs	r0, #1
	rsbs	r0, r0, #0
	cmp	r2, r0
	beq	.L0805B904
	adds	r4, r0, #0
.L0805B8E4:
	ldrb	r0, [r1, #0x16]
	cmp	r0, #0
	beq	.L0805B8FC
	ldr	r0, [r1, #0x18]
	cmp	r0, r3
	bne	.L0805B8FC
	adds	r0, r1, #0
	b	.L0805B906
.Lw0805B8F4:
	.word	snd_voices
.Lw0805B8F8:
	.word	snd_numVoices
.L0805B8FC:
	adds	r1, #0x28
	subs	r2, #1
	cmp	r2, r4
	bne	.L0805B8E4
.L0805B904:
	movs	r0, #0
.L0805B906:
	pop	{r4}
	pop	{r1}
	bx	r1

@ ==================== snd_stop  (0805B90C) ====================
@ void snd_stop(s32 h)    { if ((v = voice_find(h))) v->state = 0; }
	.thumb_func
	.global snd_stop
snd_stop:
	push	{lr}
	bl	voice_find
	adds	r1, r0, #0
	cmp	r1, #0
	beq	.L0805B91C
	movs	r0, #0
	strb	r0, [r1, #0x16]
.L0805B91C:
	pop	{r0}
	bx	r0

@ ==================== snd_pause  (0805B920) ====================
@ void snd_pause(s32 h)   { if ((v = voice_find(h))) v->state = 2; }
	.thumb_func
	.global snd_pause
snd_pause:
	push	{lr}
	bl	voice_find
	adds	r1, r0, #0
	cmp	r1, #0
	beq	.L0805B930
	movs	r0, #2
	strb	r0, [r1, #0x16]
.L0805B930:
	pop	{r0}
	bx	r0

@ ==================== snd_resume  (0805B934) ====================
@ void snd_resume(s32 h)  { if ((v = voice_find(h)) && v->state == 2) v->state = 1; }
	.thumb_func
	.global snd_resume
snd_resume:
	push	{lr}
	bl	voice_find
	adds	r1, r0, #0
	cmp	r1, #0
	beq	.L0805B94A
	ldrb	r0, [r1, #0x16]
	cmp	r0, #2
	bne	.L0805B94A
	movs	r0, #1
	strb	r0, [r1, #0x16]
.L0805B94A:
	pop	{r0}
	bx	r0
	.hword	0x0000				@ alignment padding

@ ==================== snd_setVolume  (0805B950) ====================
@ void snd_setVolume(s32 h, u32 vol)       // 0..256
@ {
@     if ((v = voice_find(h))) v->volume = vol > 256 ? 256 : vol;
@ }
	.thumb_func
	.global snd_setVolume
snd_setVolume:
	push	{r4, lr}
	adds	r4, r1, #0
	bl	voice_find
	cmp	r0, #0
	beq	.L0805B968
	movs	r1, #0x80
	lsls	r1, r1, #1
	cmp	r4, r1
	bls	.L0805B966
	adds	r4, r1, #0
.L0805B966:
	strh	r4, [r0, #0x10]
.L0805B968:
	pop	{r4}
	pop	{r0}
	bx	r0
	.hword	0x0000				@ alignment padding

@ ==================== snd_setPitch  (0805B970) ====================
@ void snd_setPitch(s32 h, u32 key)        // never called by the game
@ {
@     if ((v = voice_find(h))) v->step = snd_pitchTable[key > 127 ? 127 : key];
@ }
	.thumb_func
	.global snd_setPitch
snd_setPitch:
	push	{r4, lr}
	adds	r4, r1, #0
	bl	voice_find
	adds	r2, r0, #0
	cmp	r2, #0
	beq	.L0805B990
	cmp	r4, #0x7f
	bls	.L0805B984
	movs	r4, #0x7f
.L0805B984:
	ldr	r0, .Lw0805B998                    @ =snd_pitchTable
	ldr	r1, [r0]
	lsls	r0, r4, #2
	adds	r0, r0, r1
	ldr	r0, [r0]
	str	r0, [r2, #8]
.L0805B990:
	pop	{r4}
	pop	{r0}
	bx	r0
	.hword	0x0000				@ alignment padding
.Lw0805B998:
	.word	snd_pitchTable

@ ==================== snd_setBank  (0805B99C) ====================
@ void snd_setBank(Bank *b) { snd_bank = b; }   // game: snd_setBank(&snd_bankAI)
	.thumb_func
	.global snd_setBank
snd_setBank:
	ldr	r1, .Lw0805B9A4                    @ =snd_bank
	str	r0, [r1]
	bx	lr
	.hword	0x0000				@ alignment padding
.Lw0805B9A4:
	.word	snd_bank

@ ==================== seq_releaseAll  (0805B9A8) ====================
@ static void seq_releaseAll(void)
@ {
@     if (seq_playing != 1) return;
@     for (ch = 0; ch < 16; ch++)
@         for (j = 0; j < 4; j++)
@             if (seq_tracks[ch].slot[j].active) {
@                 snd_stop(seq_tracks[ch].slot[j].handle);
@                 seq_tracks[ch].slot[j].active = 0;
@             }
@     seq_playing = 0;
@ }
	.thumb_func
	.global seq_releaseAll
seq_releaseAll:
	push	{r4, r5, r6, r7, lr}
	sub	sp, #4
	ldr	r0, .Lw0805BA04                    @ =seq_playing
	ldr	r0, [r0]
	cmp	r0, #1
	bne	.L0805B9FC
	movs	r1, #0
	ldr	r2, .Lw0805BA08                    @ =seq_tracks
.L0805B9B8:
	movs	r6, #0
	lsls	r0, r1, #3
	adds	r7, r1, #1
	adds	r0, r0, r1
	lsls	r5, r0, #2
.L0805B9C2:
	ldr	r0, [r2]
	adds	r1, r5, r0
	lsls	r4, r6, #3
	adds	r0, r1, r4
	ldrb	r0, [r0, #4]
	cmp	r0, #0
	beq	.L0805B9EA
	adds	r0, r1, #0
	adds	r0, #8
	adds	r0, r0, r4
	ldr	r0, [r0]
	str	r2, [sp]
	bl	snd_stop
	ldr	r2, [sp]
	ldr	r0, [r2]
	adds	r0, r5, r0
	adds	r0, r0, r4
	movs	r1, #0
	strb	r1, [r0, #4]
.L0805B9EA:
	adds	r6, #1
	cmp	r6, #3
	bls	.L0805B9C2
	adds	r1, r7, #0
	cmp	r1, #0xf
	bls	.L0805B9B8
	ldr	r1, .Lw0805BA04                    @ =seq_playing
	movs	r0, #0
	str	r0, [r1]
.L0805B9FC:
	add	sp, #4
	pop	{r4, r5, r6, r7}
	pop	{r0}
	bx	r0
.Lw0805BA04:
	.word	seq_playing
.Lw0805BA08:
	.word	seq_tracks

@ ==================== seq_continue  (0805BA0C) ====================
@ void seq_continue(void)                  // never called by the game
@ {
@     if (seq_ptr) seq_playing = 1;
@ }
	.thumb_func
	.global seq_continue
seq_continue:
	ldr	r0, .Lw0805BA1C                    @ =seq_ptr
	ldr	r0, [r0]
	cmp	r0, #0
	beq	.L0805BA1A
	ldr	r1, .Lw0805BA20                    @ =seq_playing
	movs	r0, #1
	str	r0, [r1]
.L0805BA1A:
	bx	lr
.Lw0805BA1C:
	.word	seq_ptr
.Lw0805BA20:
	.word	seq_playing

@ ==================== seq_playSong  (0805BA24) ====================
@ void seq_playSong(u32 i)                 // never called: AI has no sequenced songs
@ {
@     if (i >= snd_bank->songCount) return;
@     seq_releaseAll();
@     seq_ptr = snd_bank->songs[i].start;  seq_loopPtr = snd_bank->songs[i].loop;
@     seq_wait = 0;  seq_tempo = 0;  seq_playing = 1;   // the song's first event is B2 (tempo)
@ }
	.thumb_func
	.global seq_playSong
seq_playSong:
	push	{r4, r5, lr}
	adds	r4, r0, #0
	ldr	r5, .Lw0805BA60                    @ =snd_bank
	ldr	r0, [r5]
	ldr	r0, [r0]
	cmp	r4, r0
	bhs	.L0805BA5A
	bl	seq_releaseAll
	ldr	r2, .Lw0805BA64                    @ =seq_ptr
	ldr	r0, [r5]
	ldr	r1, [r0, #8]
	lsls	r0, r4, #3
	adds	r0, r0, r1
	ldr	r1, [r0]
	str	r1, [r2]
	ldr	r1, .Lw0805BA68                    @ =seq_loopPtr
	ldr	r0, [r0, #4]
	str	r0, [r1]
	ldr	r0, .Lw0805BA6C                    @ =seq_wait
	movs	r1, #0
	str	r1, [r0]
	ldr	r0, .Lw0805BA70                    @ =seq_tempo
	str	r1, [r0]
	ldr	r1, .Lw0805BA74                    @ =seq_playing
	movs	r0, #1
	str	r0, [r1]
.L0805BA5A:
	pop	{r4, r5}
	pop	{r0}
	bx	r0
.Lw0805BA60:
	.word	snd_bank
.Lw0805BA64:
	.word	seq_ptr
.Lw0805BA68:
	.word	seq_loopPtr
.Lw0805BA6C:
	.word	seq_wait
.Lw0805BA70:
	.word	seq_tempo
.Lw0805BA74:
	.word	seq_playing

@ ==================== snd_playSfx  (0805BA78) ====================
@ int snd_playSfx(u32 i, u32 key)          // game passes key 60 = original pitch
@ {
@     if (i < snd_bank->sampleCount)
@         return snd_playSample(snd_bank->samples[i], key);
@     // out of range: returns snd_bank->sampleCount (left in r0), not -1
@ }
	.thumb_func
	.global snd_playSfx
snd_playSfx:
	push	{lr}
	adds	r2, r0, #0
	adds	r3, r1, #0
	ldr	r0, .Lw0805BA9C                    @ =snd_bank
	ldr	r1, [r0]
	ldr	r0, [r1, #4]
	cmp	r2, r0
	bhs	.L0805BA96                         @ i >= sampleCount -> return (r0 = sampleCount)
	ldr	r1, [r1, #0xc]
	lsls	r0, r2, #2
	adds	r0, r0, r1
	ldr	r0, [r0]
	adds	r1, r3, #0
	bl	snd_playSample                      @ snd_playSample(bank->samples[i], key)
.L0805BA96:
	pop	{r1}
	bx	r1
	.hword	0x0000				@ alignment padding
.Lw0805BA9C:
	.word	snd_bank

@ ==================== seq_tick  (0805BAA0) ====================
@ static void seq_tick(void)               // called from snd_update, once per frame
@ {
@     if (seq_playing != 1) return;
@     if ((seq_wait -= seq_tempo) > 0) return;     // 16.16 ticks
@     do {
@         b = *seq_ptr++;
@         if (!(b & 0x80)) {                       // delta: 15-bit big-endian tick count
@             seq_wait += ((b << 8) | *seq_ptr++) << 16;
@             continue;
@         }
@         ch = b & 15;  t = &seq_tracks[ch];
@         switch (b >> 4) {
@         case 0x8: key = seq_ptr[0]; seq_ptr += 2;           // note off (velocity ignored)
@                   first active slot with this key: snd_stop(handle), active = 0;  break;
@         case 0x9: key = seq_ptr[0]; vel = seq_ptr[1]; seq_ptr += 2;   // note on
@                   if (!t->program) break;
@                   if (any active slot already has key) break;        // no retrigger
@                   if (free slot j) { h = snd_playSample(t->program, key);
@                                      snd_setVolume(h, vel); slot = {1, key, h}; }
@                   break;                                        // 4 slots full: note dropped
@         case 0xA: break;                         // no operand consumed
@         case 0xB: switch (ch) {                  // B is NOT a controller: driver meta-commands
@                   case 0: seq_ptr = seq_loopPtr; break;               // loop
@                   case 1: seq_ptr++; break;
@                   case 2: seq_tempo = BE32(seq_ptr); seq_ptr += 4; break; // ticks/frame, 16.16
@                   case 3: dbg_printf(str_endTrack); break;            // does NOT stop the song
@                   } break;
@         case 0xC: t->program = snd_bank->samples[*seq_ptr++]; break;  // program change
@         case 0xD: seq_ptr++; break;
@         default:  break;                         // 0xE, 0xF: status byte only
@         }
@     } while (seq_wait <= 0);
@ }
	.thumb_func
	.global seq_tick
seq_tick:
	push	{r4, r5, r6, r7, lr}
	ldr	r0, .Lw0805BAE8                    @ =seq_playing
	ldr	r0, [r0]
	cmp	r0, #1
	beq	.L0805BAAC
	b	.L0805BCC6
.L0805BAAC:
	ldr	r2, .Lw0805BAEC                    @ =seq_wait
	ldr	r1, .Lw0805BAF0                    @ =seq_tempo
	ldr	r0, [r2]
	ldr	r1, [r1]
	subs	r0, r0, r1                        @ seq_wait -= seq_tempo
	str	r0, [r2]
	cmp	r0, #0
	ble	.L0805BABE
	b	.L0805BCC6
.L0805BABE:
	ldr	r3, .Lw0805BAF4                    @ =seq_ptr
	ldr	r2, [r3]
	ldrb	r5, [r2]
	adds	r2, #1
	str	r2, [r3]
	movs	r0, #0x80
	ands	r0, r5                            @ b & 0x80: clear -> delta
	adds	r4, r3, #0
	cmp	r0, #0
	bne	.L0805BAD4
	b	.L0805BCA8
.L0805BAD4:
	lsrs	r0, r5, #4
	subs	r0, #8                            @ (status >> 4) - 8 = 0..5 for 8x..Dx
	cmp	r0, #5
	bls	.L0805BADE
	b	.L0805BCBC
.L0805BADE:
	lsls	r0, r0, #2
	ldr	r1, .Lw0805BAF8                    @ =seq_dispatch
	adds	r0, r0, r1
	ldr	r0, [r0]
	mov	pc, r0                             @ jump through seq_dispatch
.Lw0805BAE8:
	.word	seq_playing
.Lw0805BAEC:
	.word	seq_wait
.Lw0805BAF0:
	.word	seq_tempo
.Lw0805BAF4:
	.word	seq_ptr
.Lw0805BAF8:
	.word	seq_dispatch
seq_dispatch:
	.word	0x0805BB14                       @ 8x note off
.Lw0805BB00:
	.word	0x0805BB5C                       @ 9x note on
.Lw0805BB04:
	.word	.L0805BCBC                       @ Ax (ignored)
.Lw0805BB08:
	.word	0x0805BC02                       @ Bx meta
.Lw0805BB0C:
	.word	0x0805BC70                       @ Cx program change
.Lw0805BB10:
	.word	.L0805BCA0                       @ Dx skip 1
	ldr	r0, [r4]
	ldrb	r3, [r0]
	adds	r0, #2                            @ note off: skip key + velocity
	str	r0, [r4]
	ldr	r2, .Lw0805BB34                    @ =seq_tracks
	movs	r0, #0xf
	ands	r0, r5
	lsls	r1, r0, #3
	adds	r1, r1, r0
	lsls	r1, r1, #2
	ldr	r0, [r2]
	adds	r0, r0, r1
	adds	r4, r0, #4
	movs	r1, #4
	b	.L0805BB3A
	.hword	0x0000				@ alignment padding
.Lw0805BB34:
	.word	seq_tracks
.L0805BB38:
	adds	r4, #8
.L0805BB3A:
	adds	r0, r1, #0
	subs	r1, #1
	cmp	r0, #0
	bne	.L0805BB44
	b	.L0805BCBC
.L0805BB44:
	ldrb	r0, [r4]
	cmp	r0, #0
	beq	.L0805BB38
	ldrb	r0, [r4, #1]
	cmp	r0, r3
	bne	.L0805BB38
	ldr	r0, [r4, #4]
	bl	snd_stop                            @ snd_stop(slot.handle)
	movs	r0, #0
	strb	r0, [r4]
	b	.L0805BCBC
	ldr	r0, [r4]
	ldrb	r6, [r0]
	adds	r0, #1
	str	r0, [r4]
	ldrb	r7, [r0]
	adds	r0, #1
	str	r0, [r4]
	movs	r1, #0xf
	ands	r1, r5
	ldr	r3, .Lw0805BBF0                    @ =seq_tracks
	ldr	r2, [r3]
	lsls	r0, r1, #3
	adds	r0, r0, r1
	lsls	r0, r0, #2
	adds	r0, r0, r2
	ldr	r2, [r0]
	mov	ip, r3
	cmp	r2, #0                             @ no program on this channel -> ignore note
	bne	.L0805BB84
	b	.L0805BCBC
.L0805BB84:
	adds	r4, r0, #4
	movs	r3, #0
	movs	r1, #3
	ldrb	r0, [r0, #4]
	cmp	r0, #0
	beq	.L0805BB98
	ldrb	r0, [r4, #1]
	cmp	r0, r6
	bne	.L0805BB98
	b	.L0805BCBC
.L0805BB98:
	adds	r4, #8
	subs	r1, #1
	movs	r0, #1
	rsbs	r0, r0, #0
	cmp	r1, r0
	beq	.L0805BBB2
	ldrb	r0, [r4]
	cmp	r0, #0
	beq	.L0805BB98
	ldrb	r0, [r4, #1]
	cmp	r0, r6
	bne	.L0805BB98
	movs	r3, #1
.L0805BBB2:
	cmp	r3, #0
	beq	.L0805BBB8
	b	.L0805BCBC
.L0805BBB8:
	movs	r0, #0xf
	ands	r0, r5
	lsls	r1, r0, #3
	adds	r1, r1, r0
	lsls	r1, r1, #2
	mov	r3, ip
	ldr	r0, [r3]
	adds	r0, r0, r1
	adds	r4, r0, #4
	movs	r1, #3
.L0805BBCC:
	ldrb	r0, [r4]
	cmp	r0, #0
	bne	.L0805BBF4
	cmp	r2, #0
	beq	.L0805BCBC
	adds	r0, r2, #0
	adds	r1, r6, #0
	bl	snd_playSample                      @ snd_playSample(program, key)
	str	r0, [r4, #4]
	adds	r1, r7, #0
	bl	snd_setVolume                       @ snd_setVolume(handle, velocity)
	movs	r0, #1
	strb	r0, [r4]
	strb	r6, [r4, #1]
	b	.L0805BCBC
	.hword	0x0000				@ alignment padding
.Lw0805BBF0:
	.word	seq_tracks
.L0805BBF4:
	adds	r4, #8
	subs	r1, #1
	movs	r0, #1
	rsbs	r0, r0, #0
	cmp	r1, r0
	bne	.L0805BBCC
	b	.L0805BCBC
	movs	r0, #0xf
	ands	r0, r5
	cmp	r0, #1
	beq	.L0805BCA0
	cmp	r0, #1
	bgt	.L0805BC14
	cmp	r0, #0
	beq	.L0805BC1E
	b	.L0805BCBC
.L0805BC14:
	cmp	r0, #2
	beq	.L0805BC2C
	cmp	r0, #3
	beq	.L0805BC64
	b	.L0805BCBC
.L0805BC1E:
	ldr	r0, .Lw0805BC28                    @ =seq_loopPtr; B0: loop
	ldr	r0, [r0]
	str	r0, [r4]
	b	.L0805BCBC
	.hword	0x0000				@ alignment padding
.Lw0805BC28:
	.word	seq_loopPtr
.L0805BC2C:
	ldr	r3, .Lw0805BC60                    @ =seq_tempo; B2: tempo, 4 bytes big-endian
	ldr	r0, [r4]
	ldrb	r5, [r0]
	lsls	r2, r5, #0x18
	str	r2, [r3]
	adds	r0, #1
	str	r0, [r4]
	ldrb	r5, [r0]
	lsls	r1, r5, #0x10
	orrs	r1, r2
	str	r1, [r3]
	adds	r2, r0, #1
	str	r2, [r4]
	ldrb	r0, [r0, #1]
	lsls	r0, r0, #8
	orrs	r0, r1
	str	r0, [r3]
	adds	r1, r2, #1
	str	r1, [r4]
	ldrb	r2, [r2, #1]
	orrs	r0, r2
	str	r0, [r3]
	adds	r1, #1
	str	r1, [r4]
	b	.L0805BCBC
	.hword	0x0000				@ alignment padding
.Lw0805BC60:
	.word	seq_tempo
.L0805BC64:
	ldr	r0, .Lw0805BC6C                    @ =str_endTrack; B3: debug print only, playback continues
	bl	dbg_printf
	b	.L0805BCBC
.Lw0805BC6C:
	.word	str_endTrack
	ldr	r0, [r4]
	ldrb	r3, [r0]
	adds	r0, #1
	str	r0, [r4]
	movs	r2, #0xf
	ands	r2, r5
	ldr	r0, .Lw0805BC98                    @ =seq_tracks
	ldr	r0, [r0]
	lsls	r1, r2, #3
	adds	r1, r1, r2
	lsls	r1, r1, #2
	adds	r1, r1, r0
	ldr	r0, .Lw0805BC9C                    @ =snd_bank
	ldr	r0, [r0]
	ldr	r0, [r0, #0xc]
	lsls	r3, r3, #2
	adds	r3, r3, r0
	ldr	r0, [r3]
	str	r0, [r1]                           @ Cn: program = bank->samples[pp]
	b	.L0805BCBC
.Lw0805BC98:
	.word	seq_tracks
.Lw0805BC9C:
	.word	snd_bank
.L0805BCA0:
	ldr	r0, [r4]                           @ Dn: skip one byte
	adds	r0, #1
	str	r0, [r4]
	b	.L0805BCBC
.L0805BCA8:
	lsls	r1, r5, #8                        @ delta: ((b<<8)|next) << 16
	ldrb	r0, [r2]
	orrs	r1, r0
	adds	r0, r2, #1
	str	r0, [r3]
	ldr	r2, .Lw0805BCCC                    @ =seq_wait
	lsls	r1, r1, #0x10
	ldr	r0, [r2]
	adds	r0, r0, r1
	str	r0, [r2]
.L0805BCBC:
	ldr	r0, .Lw0805BCCC                    @ =seq_wait
	ldr	r0, [r0]
	cmp	r0, #0
	bgt	.L0805BCC6
	b	.L0805BABE                           @ loop while seq_wait <= 0
.L0805BCC6:
	pop	{r4, r5, r6, r7}
	pop	{r0}
	bx	r0
.Lw0805BCCC:
	.word	seq_wait

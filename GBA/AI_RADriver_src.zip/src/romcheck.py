#!/usr/bin/env python3
"""romcheck.py ELF ROM -- compare every allocated section of the rebuilt ELF with the ROM at its load address."""
import sys,struct
elf=open(sys.argv[1],'rb').read(); rom=open(sys.argv[2],'rb').read()
shoff,=struct.unpack_from('<I',elf,0x20); shentsize,shnum,shstrndx=struct.unpack_from('<HHH',elf,0x2E)
phoff,=struct.unpack_from('<I',elf,0x1C); phentsize,phnum=struct.unpack_from('<HH',elf,0x2A)
segs=[struct.unpack_from('<IIIIIIII',elf,phoff+i*phentsize) for i in range(phnum)]
def lma(vaddr):
    for t,off,va,pa,fs,ms,fl,al in segs:
        if va<=vaddr<va+ms: return pa+(vaddr-va)
    return vaddr
sh=[struct.unpack_from('<IIIIIIIIII',elf,shoff+i*shentsize) for i in range(shnum)]
strtab=sh[shstrndx][4]
ok=True;total=0
for name,typ,flags,addr,off,size,*_ in sh:
    if typ!=1 or not(flags&2) or size==0: continue
    nm=elf[strtab+name:elf.index(b'\0',strtab+name)].decode()
    la=lma(addr);r=rom[la-0x08000000:la-0x08000000+size];b=elf[off:off+size]
    same=(r==b);ok&=same;total+=size
    print(f'{nm:10s} {addr:08X} (ROM {la:08X}) {size:8d} bytes  {"identical" if same else "DIFFERENT"}')
    if not same:
        i=next(i for i in range(size) if r[i]!=b[i]); print(f'   first difference at {la+i:08X}')
print(f'{total} bytes checked:', 'ALL IDENTICAL' if ok else 'MISMATCH'); sys.exit(0 if ok else 1)
